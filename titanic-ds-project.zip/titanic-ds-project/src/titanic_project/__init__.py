"""Titanic data-science project: an end-to-end, reproducible pipeline.

Stages: ingest -> clean -> EDA -> statistical inference -> machine learning -> visualization.
"""
__version__ = "1.0.0"
