"""Small statistical helpers shared by several stages."""
import numpy as np


def wilson(k, n, z=1.96):
    """95 % Wilson score interval for a proportion k/n."""
    p = k / n
    den = 1 + z ** 2 / n
    centre = (p + z ** 2 / (2 * n)) / den
    half = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
    return float(max(0.0, centre - half)), float(min(1.0, centre + half))   # clip: rounding can push a bound outside [0, 1]


def to_jsonable(obj):
    """Recursively convert numpy / pandas scalars so that results can be written as JSON."""
    import pandas as pd
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, pd.Series):
        return to_jsonable(obj.to_dict())
    return obj
