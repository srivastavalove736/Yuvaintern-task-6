"""Stage 5: machine learning (leakage-free pipelines, nested cross-validation, hold-out evaluation).

All fitted preprocessing lives inside scikit-learn Pipelines and is re-fitted on the training part of every fold.
The held-out test set is used exactly once, after the model and the decision threshold have been fixed.
"""
import time
import warnings
import numpy as np
import pandas as pd
from scipy.stats import loguniform, randint, binomtest
from sklearn.base import BaseEstimator, TransformerMixin, clone
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss, confusion_matrix, f1_score, matthews_corrcoef,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import (RandomizedSearchCV, RepeatedStratifiedKFold, StratifiedKFold, cross_val_predict, cross_validate,
                                     learning_curve, train_test_split, validation_curve)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from . import config

RS = config.RANDOM_STATE
# The dummy baseline predicts no positives, so precision is undefined for it by construction: expected, not an error.
warnings.filterwarnings("ignore", message="Precision is ill-defined")
warnings.filterwarnings("ignore", message=".*Maximum Likelihood optimization failed to converge.*")
FEATURES = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked", "Title", "Family_Size", "Is_Alone", "Has_Cabin", "Ticket_Size"]
NUM, LOGNUM, BIN, CAT = ["Age", "SibSp", "Parch", "Family_Size", "Ticket_Size"], ["Fare"], ["Is_Alone", "Has_Cabin", "Age_Missing"], ["Sex", "Embarked", "Title", "Pclass"]
SCORING = {"auc": "roc_auc", "acc": "accuracy", "prec": "precision", "rec": "recall", "f1": "f1", "brier": "neg_brier_score"}
RANK = ["Logistic regression", "SVM (RBF)", "Random forest", "Gradient boosting"]      # simplest first (selection tie-break)


def engineer(raw):
    """Row-wise feature engineering from the RAW file (uses no statistics learned from other rows, except Ticket_Size)."""
    d = raw.copy()
    t = d.Name.str.strip().str.extract(r",\s*([^.]*)\.")[0].str.strip().replace({"Mlle": "Miss", "Ms": "Miss", "Mme": "Mrs"})
    t = t.replace(["Col", "Major", "Capt"], "Officer").replace(["Don", "Lady", "Sir", "the Countess", "Jonkheer", "Dona"], "Noble").replace(["Dr", "Rev"], "Professional")
    d["Title"] = t
    d["Sex"] = d.Sex.str.strip().str.lower()
    d["Pclass"] = d.Pclass.astype(str)
    d["Family_Size"] = d.SibSp + d.Parch + 1
    d["Is_Alone"] = (d.Family_Size == 1).astype(int)
    d["Has_Cabin"] = d.Cabin.notna().astype(int)
    d["Ticket_Size"] = d.groupby("Ticket").PassengerId.transform("count")
    return d


class AgeImputer(BaseEstimator, TransformerMixin):
    """Median Age by Title x Pclass (fall-back: Title, then overall median), learned on training data only."""
    def fit(self, X, y=None):
        self.global_ = X.Age.median()
        self.group_ = X.groupby(["Title", "Pclass"]).Age.median().dropna().to_dict()
        self.title_ = X.groupby("Title").Age.median().dropna().to_dict()
        return self

    def transform(self, X):
        X = X.copy()
        X["Age_Missing"] = X.Age.isna().astype(int)
        fill = [self.group_.get((t, p), self.title_.get(t, self.global_)) for t, p in zip(X.Title, X.Pclass)]
        X["Age"] = X.Age.fillna(pd.Series(fill, index=X.index))
        return X


def make_pipeline(clf, drop=()):
    parts = []
    if [c for c in NUM if c not in drop]:
        parts.append(("num", StandardScaler(), [c for c in NUM if c not in drop]))
    if [c for c in LOGNUM if c not in drop]:
        parts.append(("lognum", Pipeline([("log", FunctionTransformer(np.log1p, feature_names_out="one-to-one")), ("sc", StandardScaler())]), [c for c in LOGNUM if c not in drop]))
    if [c for c in BIN if c not in drop]:
        parts.append(("bin", "passthrough", [c for c in BIN if c not in drop]))
    parts.append(("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")), ("oh", OneHotEncoder(handle_unknown="ignore"))]), [c for c in CAT if c not in drop]))
    prep = ColumnTransformer(parts, sparse_threshold=0, verbose_feature_names_out=False)
    return Pipeline([("age", AgeImputer()), ("prep", prep), ("clf", clf)])


def candidates():
    return {"Dummy (prior)": DummyClassifier(strategy="prior"), "Logistic regression": LogisticRegression(max_iter=2000),
            "Decision tree": DecisionTreeClassifier(random_state=RS), "k-nearest neighbours": KNeighborsClassifier(),
            "SVM (RBF)": SVC(probability=True, random_state=RS), "Random forest": RandomForestClassifier(n_estimators=300, random_state=RS),
            "Gradient boosting": GradientBoostingClassifier(random_state=RS)}


def search_spaces(fast=False):
    s = {"Logistic regression": (LogisticRegression(max_iter=3000), {"clf__C": loguniform(1e-3, 1e2), "clf__class_weight": [None, "balanced"]}, 15),
         "SVM (RBF)": (SVC(probability=True, random_state=RS), {"clf__C": loguniform(1e-1, 1e2), "clf__gamma": loguniform(1e-3, 1e0), "clf__class_weight": [None, "balanced"]}, 15),
         "Random forest": (RandomForestClassifier(random_state=RS), {"clf__n_estimators": [200, 400], "clf__max_depth": [3, 4, 5, 6, 8, None], "clf__min_samples_leaf": [1, 2, 4, 8],
                                                                      "clf__max_features": ["sqrt", 0.3, 0.5], "clf__class_weight": [None, "balanced_subsample"]}, 12),
         "Gradient boosting": (GradientBoostingClassifier(random_state=RS), {"clf__n_estimators": randint(50, 400), "clf__learning_rate": loguniform(0.01, 0.3), "clf__max_depth": [2, 3, 4],
                                                                              "clf__subsample": [0.6, 0.8, 1.0], "clf__min_samples_leaf": [1, 5, 10, 20]}, 15)}
    if fast:
        s = {k: (c, sp, 3) for k, (c, sp, n) in s.items() if k in ("Logistic regression", "Random forest")}
    return s


def _clean_params(p):
    return {k.replace("clf__", ""): (round(float(v), 4) if isinstance(v, (float, np.floating)) else v) for k, v in p.items()}


def metrics(yt, p, thr):
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(yt, pred).ravel()
    return {"auc": roc_auc_score(yt, p), "pr_auc": average_precision_score(yt, p), "accuracy": accuracy_score(yt, pred), "precision": precision_score(yt, pred),
            "recall": recall_score(yt, pred), "f1": f1_score(yt, pred), "mcc": matthews_corrcoef(yt, pred), "brier": brier_score_loss(yt, p),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def run(raw, fast=False, verbose=True):
    """Run the whole machine-learning stage. Returns (results dict, context dict with fitted objects for plotting/saving)."""
    T0 = time.time()
    say = (lambda *a: print(*a, flush=True)) if verbose else (lambda *a: None)
    R, ctx = {}, {}
    data = engineer(raw)
    X, y = data[FEATURES], data.Survived.values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=config.TEST_SIZE, stratify=y, random_state=RS)
    R["split"] = {"n_train": len(X_train), "n_test": len(X_test), "train_rate": float(y_train.mean()), "test_rate": float(y_test.mean()), "baseline_acc_test": float(1 - y_test.mean())}
    R["features"] = FEATURES
    demo = make_pipeline(LogisticRegression(max_iter=2000)).fit(X_train, y_train)
    R["n_model_inputs"] = int(len(demo.named_steps["prep"].get_feature_names_out()))

    # ---- baseline comparison with default hyperparameters
    cv15 = RepeatedStratifiedKFold(n_splits=5, n_repeats=1 if fast else 3, random_state=RS)
    cand = candidates()
    if fast:
        cand = {k: v for k, v in cand.items() if k in ("Dummy (prior)", "Logistic regression", "Random forest")}
    base_rows, base_auc = [], {}
    for name, clf in cand.items():
        r = cross_validate(make_pipeline(clf), X_train, y_train, cv=cv15, scoring=SCORING, return_train_score=True)
        base_auc[name] = r["test_auc"].tolist()
        base_rows.append({"model": name, "AUC": r["test_auc"].mean(), "AUC_sd": r["test_auc"].std(), "train_AUC": r["train_auc"].mean(), "Accuracy": r["test_acc"].mean(), "Acc_sd": r["test_acc"].std(),
                          "Precision": r["test_prec"].mean(), "Recall": r["test_rec"].mean(), "F1": r["test_f1"].mean(), "Brier": -r["test_brier"].mean()})
    base = pd.DataFrame(base_rows)
    R["baseline"] = base.to_dict("records")
    say(f"baseline done ({time.time() - T0:.0f}s)")

    # ---- nested cross-validation (outer 5-fold estimates performance, inner 3-fold randomized search tunes)
    spaces = search_spaces(fast)
    outer = StratifiedKFold(n_splits=3 if fast else 5, shuffle=True, random_state=1)
    inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=2)
    nest_rows, fold_params, nest_auc = [], {}, {}
    for name, (clf, space, n_iter) in spaces.items():
        search = RandomizedSearchCV(make_pipeline(clf), space, n_iter=n_iter, cv=inner, scoring="roc_auc", random_state=RS, n_jobs=1)
        r = cross_validate(search, X_train, y_train, cv=outer, scoring=SCORING, return_estimator=True)
        nest_auc[name] = r["test_auc"].tolist()
        fold_params[name] = [_clean_params(e.best_params_) for e in r["estimator"]]
        nest_rows.append({"model": name, "nested_AUC": r["test_auc"].mean(), "nested_AUC_sd": r["test_auc"].std(), "nested_AUC_se": r["test_auc"].std(ddof=1) / np.sqrt(len(r["test_auc"])),
                          "Accuracy": r["test_acc"].mean(), "Precision": r["test_prec"].mean(), "Recall": r["test_rec"].mean(), "F1": r["test_f1"].mean(), "Brier": -r["test_brier"].mean(),
                          "untuned_AUC": float(base.set_index("model").loc[name, "AUC"])})
        say(f"nested CV {name}: AUC {r['test_auc'].mean():.3f} ({time.time() - T0:.0f}s)")
    nest = pd.DataFrame(nest_rows)
    R["nested"], R["fold_params"] = nest.to_dict("records"), fold_params

    # ---- pre-declared selection rule: best nested AUC; prefer the simplest model within one standard error
    best = nest.loc[nest.nested_AUC.idxmax()]
    thr_se = best.nested_AUC - best.nested_AUC_se
    within = nest[nest.nested_AUC >= thr_se].model.tolist()
    CHOSEN = [m for m in RANK if m in within][0]
    R["selection"] = {"best_by_auc": best.model, "best_auc": float(best.nested_AUC), "best_se": float(best.nested_AUC_se), "one_se_threshold": float(thr_se), "within_one_se": within, "chosen": CHOSEN}
    say("chosen model:", CHOSEN)

    # ---- final tuning on the full training set
    tuned, tuned_rows = {}, []
    for name, (clf, space, n_iter) in spaces.items():
        s = RandomizedSearchCV(make_pipeline(clf), space, n_iter=n_iter, cv=StratifiedKFold(5, shuffle=True, random_state=3), scoring="roc_auc", random_state=RS, n_jobs=1).fit(X_train, y_train)
        tuned[name] = s.best_estimator_
        tuned_rows.append({"model": name, "best_cv_AUC": float(s.best_score_), "params": _clean_params(s.best_params_)})
    R["tuned"] = tuned_rows
    final_pipe = tuned[CHOSEN]

    # ---- decision threshold from out-of-fold training predictions only
    oof = cross_val_predict(clone(final_pipe), X_train, y_train, cv=StratifiedKFold(5, shuffle=True, random_state=7), method="predict_proba")[:, 1]
    grid = np.linspace(0.20, 0.80, 61)
    f1s = [f1_score(y_train, oof >= t) for t in grid]
    THR = float(grid[int(np.argmax(f1s))])
    R["threshold"] = {"oof_auc": float(roc_auc_score(y_train, oof)), "thr_f1": THR, "f1_at_thr": float(max(f1s)), "f1_at_05": float(f1_score(y_train, oof >= .5)),
                      "recall_at_thr": float(recall_score(y_train, oof >= THR)), "recall_at_05": float(recall_score(y_train, oof >= .5)),
                      "precision_at_thr": float(precision_score(y_train, oof >= THR)), "precision_at_05": float(precision_score(y_train, oof >= .5))}

    # ---- final evaluation on the untouched test set (first and only use)
    final_pipe.fit(X_train, y_train)
    p_test = final_pipe.predict_proba(X_test)[:, 1]
    R["test_05"], R["test_thr"] = metrics(y_test, p_test, 0.5), metrics(y_test, p_test, THR)
    ref = {}
    for name in ["Logistic regression"] + ([] if CHOSEN == "Logistic regression" else [CHOSEN]):
        ref[name] = metrics(y_test, tuned[name].fit(X_train, y_train).predict_proba(X_test)[:, 1], 0.5)
    ref["Dummy (prior)"] = metrics(y_test, make_pipeline(DummyClassifier(strategy="prior")).fit(X_train, y_train).predict_proba(X_test)[:, 1], 0.5)
    R["test_ref"] = ref
    rng = np.random.default_rng(0)
    B = {k: [] for k in ["auc", "accuracy", "f1", "recall", "precision"]}
    for _ in range(1000):
        idx = rng.integers(0, len(y_test), len(y_test))
        if len(np.unique(y_test[idx])) < 2:
            continue
        mm = metrics(y_test[idx], p_test[idx], THR)
        for k in B:
            B[k].append(mm[k])
    R["test_ci"] = {k: [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))] for k, v in B.items()}
    if CHOSEN != "Logistic regression":
        p_b = tuned["Logistic regression"].predict_proba(X_test)[:, 1]
        pr_c, pr_b = (p_test >= .5).astype(int), (p_b >= .5).astype(int)
        only_c = int(((pr_c == y_test) & (pr_b != y_test)).sum()); only_b = int(((pr_c != y_test) & (pr_b == y_test)).sum())
        rng = np.random.default_rng(1); d_auc, d_acc = [], []
        for _ in range(2000):
            i = rng.integers(0, len(y_test), len(y_test))
            if len(np.unique(y_test[i])) < 2:
                continue
            d_auc.append(roc_auc_score(y_test[i], p_test[i]) - roc_auc_score(y_test[i], p_b[i])); d_acc.append(accuracy_score(y_test[i], pr_c[i]) - accuracy_score(y_test[i], pr_b[i]))
        R["paired"] = {"chosen": CHOSEN, "benchmark": "Logistic regression", "only_chosen_right": only_c, "only_benchmark_right": only_b,
                       "mcnemar_exact_p": float(binomtest(min(only_c, only_b), only_c + only_b, 0.5).pvalue) if only_c + only_b else 1.0,
                       "auc_diff": float(roc_auc_score(y_test, p_test) - roc_auc_score(y_test, p_b)), "auc_diff_ci": [float(np.percentile(d_auc, 2.5)), float(np.percentile(d_auc, 97.5))],
                       "acc_diff": float(accuracy_score(y_test, pr_c) - accuracy_score(y_test, pr_b)), "acc_diff_ci": [float(np.percentile(d_acc, 2.5)), float(np.percentile(d_acc, 97.5))]}

    # ---- diagnostics (bias/variance), interpretation, error analysis
    sizes, trs, vas = learning_curve(clone(final_pipe), X_train, y_train, cv=StratifiedKFold(5, shuffle=True, random_state=5), train_sizes=np.linspace(0.2, 1.0, 3 if fast else 6), scoring="roc_auc")
    R["learning"] = {"sizes": sizes.tolist(), "train": trs.mean(1).tolist(), "val": vas.mean(1).tolist()}
    if not fast:
        pi = permutation_importance(final_pipe, X_test, y_test, scoring="roc_auc", n_repeats=50, random_state=0)
        R["perm_importance"] = pd.DataFrame({"feature": FEATURES, "mean": pi.importances_mean, "sd": pi.importances_std}).sort_values("mean", ascending=False).round(4).to_dict("records")
    te = X_test.copy()
    te["y"], te["p"] = y_test, p_test
    te["pred"] = (p_test >= THR).astype(int)
    te["correct"] = (te.pred == te.y).astype(int)
    te["Age_f"] = final_pipe.named_steps["age"].transform(X_test).Age
    grp = te.groupby(["Sex", "Pclass"]).apply(lambda g: pd.Series({"n": len(g), "survival_rate": g.y.mean(), "accuracy": g.correct.mean(), "recall": g.pred[g.y == 1].mean() if (g.y == 1).any() else np.nan}), include_groups=False).reset_index()
    te["age_group"] = pd.cut(te.Age_f, [0, 12, 18, 35, 60, 120], labels=["Child", "Teen", "Young adult", "Adult", "Senior"], right=False)
    ag = te.groupby("age_group", observed=True).correct.agg(["mean", "size"])
    R["error_groups"] = grp.to_dict("records")
    R["error_summary"] = {"n_errors": int((1 - te.correct).sum()), "false_pos": int(((te.pred == 1) & (te.y == 0)).sum()), "false_neg": int(((te.pred == 0) & (te.y == 1)).sum()),
                          "confident_errors": int((np.abs(te.p - te.y) > 0.8).sum()), "acc_by_age_group": {str(k): float(v) for k, v in ag["mean"].items()}, "n_by_age_group": {str(k): int(v) for k, v in ag["size"].items()}}
    R["runtime_seconds"] = round(time.time() - T0)
    ctx.update({"final_pipe": final_pipe, "X_train": X_train, "X_test": X_test, "y_train": y_train, "y_test": y_test, "p_test": p_test, "oof": oof, "thr": THR,
                "ids_train": data.PassengerId.loc[X_train.index].values, "ids_test": data.PassengerId.loc[X_test.index].values, "base_auc": base_auc, "nest_auc": nest_auc})
    return R, ctx


def pdp(pipe, data, col, values):
    """Manual partial dependence on the raw-column pipeline: mean predicted probability when one feature is set to each value."""
    out = []
    for v in values:
        d = data.copy()
        d[col] = v
        if col == "Family_Size":
            d["Is_Alone"] = int(v == 1)
        out.append(float(pipe.predict_proba(d)[:, 1].mean()))
    return np.array(out)
