"""Stage 6: figures for the integrated report (consistent colour language, data-driven titles)."""
import textwrap
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.ticker import PercentFormatter
from sklearn.calibration import calibration_curve
from sklearn.metrics import roc_curve
from . import config
from .config import INK, MUTED, GRID, SURV, DIED, WOMEN, MEN, CLASS_COL

SRC = "Source: Titanic passenger manifest (n = 891)."


def style():
    mpl.rcParams.update({"font.family": ["Carlito", "DejaVu Sans"], "font.size": 11.5, "axes.edgecolor": "#BBBBBB", "axes.labelcolor": INK, "xtick.color": INK,
                         "ytick.color": INK, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": False, "figure.facecolor": "white"})


def titled(fig, title, sub=None, note=None, tx=0.04):
    W, H = fig.get_figwidth(), fig.get_figheight()
    tt = textwrap.fill(title, int(W * 7.6))
    n = tt.count("\n") + 1
    fig.text(tx, 0.972, tt, fontsize=18.5, fontweight="bold", va="top", ha="left", color=INK, linespacing=1.15)
    if sub:
        fig.text(tx, 0.972 - (n * 18.5 * 1.25 / 72 + 0.13) / H, textwrap.fill(sub, int(W * 11.0)), fontsize=12, va="top", ha="left", color=MUTED, linespacing=1.3)
    if note:
        fig.text(tx, 0.012, textwrap.fill(note, int(W * 15.5)), fontsize=9, va="bottom", ha="left", color=MUTED, linespacing=1.25)


def save(fig, name):
    config.FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(config.FIG_DIR / f"{name}.png", dpi=200, facecolor="white")
    plt.close(fig)


# ---------------------------------------------------------------- Figure 1: workflow
def fig_workflow(prov, log, E, I, M):
    fig, ax = plt.subplots(figsize=(12.5, 6.6)); ax.set_xlim(0, 12.5); ax.set_ylim(0, 6.6); ax.axis("off")
    fig.subplots_adjust(left=0.01, right=0.99, top=0.84, bottom=0.04)
    steps = [("1. Collect", "Raw manifest", f"{prov['n_rows']} passengers\n{prov['n_cols']} columns\nSHA-256 recorded", "#9A9A9A"),
             ("2. Clean", "Preprocessing", f"{len(log['checks'])} quality checks\n{log['shape_clean'][1]} columns\nno rows removed", "#7A5C00"),
             ("3. Explore", "EDA", f"{len(E['tests'])} association tests\nSpearman matrix\ngroup rates + CIs", "#CC79A7"),
             ("4. Model", "Statistics", f"5 logistic models compared\nLR tests, odds ratios\ncalibration check", "#009E73"),
             ("5. Predict", "Machine learning", f"{len(M['nested'])} tuned models\nnested cross-validation\n{M['split']['n_test']}-passenger test", SURV),
             ("6. Communicate", "Visualization", "9 figures\nintegrated report\nreproducible code", DIED)]
    w, gap = 1.72, 0.30
    for i, (t, sub, body, col) in enumerate(steps):
        x = 0.25 + i * (w + gap)
        ax.add_patch(FancyBboxPatch((x, 3.05), w, 2.45, boxstyle="round,pad=0.02,rounding_size=0.12", fc="white", ec=col, lw=2.5))
        ax.add_patch(FancyBboxPatch((x, 4.85), w, 0.65, boxstyle="round,pad=0.02,rounding_size=0.12", fc=col, ec=col))
        ax.text(x + w / 2, 5.17, t, ha="center", va="center", color="white", fontsize=14, fontweight="bold")
        ax.text(x + w / 2, 4.55, sub, ha="center", va="center", color=INK, fontsize=12, fontweight="bold")
        ax.text(x + w / 2, 3.85, body, ha="center", va="center", color=MUTED, fontsize=10.5, linespacing=1.4)
        if i < len(steps) - 1:
            ax.add_patch(FancyArrowPatch((x + w + 0.03, 4.2), (x + w + gap - 0.03, 4.2), arrowstyle="-|>", mutation_scale=16, color="#888888", lw=1.8))
    ax.add_patch(FancyBboxPatch((0.25, 0.55), 12.0, 1.9, boxstyle="round,pad=0.02,rounding_size=0.12", fc="#F6F8FB", ec="#D0D7E2", lw=1.2))
    ax.text(0.5, 2.15, "Safeguards applied across the whole pipeline", fontsize=12.5, fontweight="bold", color=INK, va="center")
    notes = ["One seed (42) controls every random step; one command rebuilds every number and figure.",
             "Predictive stage re-fits all preprocessing inside cross-validation folds, so no information leaks from validation data.",
             "Test set (20 %) is used once, after the model and the decision threshold are fixed; selection rule declared in advance.",
             "Uncertainty is reported everywhere: Wilson and bootstrap intervals, likelihood-ratio tests, fold-to-fold variation."]
    for i, n in enumerate(notes):
        ax.text(0.5, 1.7 - i * 0.33, "\u2022  " + n, fontsize=10.5, color=INK, va="center")
    titled(fig, "One pipeline, six stages: from the raw manifest to a reproducible report",
           "Each stage feeds the next and writes its results to a single file, so every number in the report can be traced to code.", SRC)
    save(fig, "fig01_workflow")


# ---------------------------------------------------------------- Figure 2: data quality
def fig_data_quality(E, log):
    mi = E["missingness_raw"]
    cols = list(mi)
    M_ = pd.DataFrame({c: {"Cabin number": mi[c]["Cabin"], "Age": mi[c]["Age"], "Port of embarkation": mi[c]["Embarked"]} for c in cols})
    fig, ax = plt.subplots(figsize=(11.5, 5.8)); fig.subplots_adjust(left=0.19, right=0.97, top=0.68, bottom=0.12)
    sns.heatmap(M_, annot=M_.map(lambda v: "<1%" if 0 < v < 0.005 else f"{v:.0%}"), fmt="", cmap=sns.light_palette(DIED, as_cmap=True), vmin=0, vmax=1, cbar=False,
                linewidths=3, linecolor="white", annot_kws={"fontsize": 16, "fontweight": "bold"}, ax=ax)
    ax.set_xlabel(""); ax.set_ylabel(""); ax.xaxis.tick_top(); ax.tick_params(length=0, labelsize=12.5); plt.setp(ax.get_yticklabels(), rotation=0); ax.axvline(4, color=INK, lw=2.2)
    titled(fig, f"Cabin numbers are missing for {mi['All']['Cabin']:.0%} of passengers, and the gaps are not random",
           f"Share of values MISSING by group (raw file). Cabin is missing for {mi['First class']['Cabin']:.0%} of first class but {mi['Third class']['Cabin']:.0%} of third class; age for {mi['All']['Age']:.0%} overall.",
           f"Source: raw manifest. Decisions: age imputed by median of title x class (mean age {log['age_mean_raw']:.1f} before, {log['age_mean_clean']:.1f} after), port filled with the mode, cabin replaced by a 'cabin recorded' flag and a deck.")
    save(fig, "fig02_data_quality")


# ---------------------------------------------------------------- Figure 3: sex x class
def fig_sex_class(E):
    rows = E["rates"]["Sex_x_Pclass"]
    rate = {(r["sex"], r["pclass"]): r for r in rows}
    gap = {int(k): v for k, v in E["sex_class_gap_points"].items()}
    fig, ax = plt.subplots(figsize=(11, 7.2)); fig.subplots_adjust(left=0.08, right=0.86, top=0.80, bottom=0.11)
    for sex, col, up in [("Female", WOMEN, True), ("Male", MEN, False)]:
        s = [rate[(sex, c)] for c in [1, 2, 3]]
        x = [1, 2, 3]; y = np.array([r["rate"] for r in s]); lo = np.array([r["lo"] for r in s]); hi = np.array([r["hi"] for r in s])
        ax.errorbar(x, y, yerr=[y - lo, hi - y], color=col, lw=3, marker="o", ms=10, capsize=5, elinewidth=1.6, zorder=3)
        for xi, r in zip(x, s):
            yy = r["hi"] + 0.022 if up else r["lo"] - 0.022
            ax.text(xi, yy, f"{r['rate']:.0%}", color=col, fontsize=15, fontweight="bold", ha="center", va="bottom" if up else "top")
            ax.text(xi + 0.15, yy + (0.004 if up else -0.004), f"n={r['n']}", color=MUTED, fontsize=9.5, ha="left", va="bottom" if up else "top")
    ax.axhline(E["overall_survival"], color="#999999", ls=(0, (4, 4)), lw=1.2); ax.text(2.45, E["overall_survival"] + 0.012, f"all passengers: {E['overall_survival']:.0%}", color=MUTED, fontsize=10.5)
    ax.text(3.2, rate[("Female", 3)]["rate"], "Women", color=WOMEN, fontsize=16, fontweight="bold", va="center"); ax.text(3.2, rate[("Male", 3)]["rate"], "Men", color=MEN, fontsize=16, fontweight="bold", va="center")
    f1 = rate[("Female", 1)]
    ax.annotate(f"Only {f1['n'] - f1['survived']} of {f1['n']} first-class\nwomen died", xy=(1.03, 0.90), xytext=(1.2, 0.70), fontsize=11.5, arrowprops=dict(arrowstyle="-", color="#888888", lw=1))
    ax.annotate(f"Third-class women ({rate[('Female', 3)]['rate']:.0%}) still outlived\nevery group of men, even first class ({rate[('Male', 1)]['rate']:.0%})", xy=(2.95, rate[("Female", 3)]["rate"] + 0.01), xytext=(1.45, 0.555), fontsize=11.5, arrowprops=dict(arrowstyle="->", color="#888888", lw=1))
    ax.set_xlim(0.6, 3.6); ax.set_ylim(0, 1.12); ax.set_xticks([1, 2, 3]); ax.set_xticklabels(["First class", "Second class", "Third class"], fontsize=13)
    ax.yaxis.set_major_formatter(PercentFormatter(1)); ax.set_yticks([0, .2, .4, .6, .8, 1.0]); ax.set_ylabel("Survival rate"); ax.grid(axis="y", color=GRID, zorder=0)
    titled(fig, f"Women outlived men in every class: the gap was {gap[1]:.0f} points in first class, {gap[2]:.0f} in second and {gap[3]:.0f} in third",
           "Survival rate by sex and passenger class. Lines that are not parallel mean the effect of sex depends on class.", SRC + " Bars: 95% Wilson intervals. Gap = women's rate minus men's rate, in percentage points.")
    save(fig, "fig03_sex_by_class")


# ---------------------------------------------------------------- Figure 4: age
def fig_age(df):
    real = df[df.Age_Imputed == 0]

    def nw(x, y, grid, bw=5.0):
        w = np.exp(-0.5 * ((grid[:, None] - x[None, :]) / bw) ** 2)
        return (w * y).sum(1) / w.sum(1), w.sum(1)

    rng = np.random.default_rng(5); grid = np.arange(1, 76, 1.0); curves = {}
    for sex in ["Female", "Male"]:
        s = real[real.Sex == sex]; x, y = s.Age.values, s.Survived.values
        est, eff = nw(x, y, grid)
        boots = np.array([nw(x[i], y[i], grid)[0] for i in (rng.integers(0, len(x), len(x)) for _ in range(300))])
        lo, hi = np.percentile(boots, [2.5, 97.5], axis=0)
        curves[sex] = (est, lo, hi, eff >= 12)
    fig = plt.figure(figsize=(11.5, 7.8)); gs = fig.add_gridspec(2, 1, height_ratios=[3.4, 1], hspace=0.08, left=0.085, right=0.93, top=0.76, bottom=0.14)
    ax = fig.add_subplot(gs[0]); axb = fig.add_subplot(gs[1], sharex=ax)
    for sex, col, lab in [("Female", WOMEN, "Women"), ("Male", MEN, "Men")]:
        est, lo, hi, ok = curves[sex]
        ax.fill_between(grid[ok], lo[ok], hi[ok], color=col, alpha=0.18, lw=0); ax.plot(grid[ok], est[ok], color=col, lw=3)
        ax.text(grid[ok][-1] + 0.8, est[ok][-1], lab, color=col, fontsize=15, fontweight="bold", va="center")
    u5 = real[real.Age < 5]; k5, n5 = int(u5.Survived.sum()), len(u5)
    ax.annotate(f"Children under 5: {k5 / n5:.0%} survived\n({k5} of {n5})", xy=(2.5, 0.68), xytext=(17, 0.93), fontsize=11.5, arrowprops=dict(arrowstyle="->", color="#888888"))
    m_u5 = real[(real.Sex == "Male") & (real.Age < 5)].Survived.mean(); m_13 = real[(real.Sex == "Male") & (real.Age >= 13)].Survived.mean()
    ax.set_ylim(0, 1.02); ax.yaxis.set_major_formatter(PercentFormatter(1)); ax.set_ylabel("Estimated survival probability"); ax.grid(axis="y", color=GRID); plt.setp(ax.get_xticklabels(), visible=False)
    bins = np.arange(0, 85, 5)
    for off, (sex, col) in zip([-0.9, 0.9], [("Female", WOMEN), ("Male", MEN)]):
        c, _ = np.histogram(real[real.Sex == sex].Age, bins=bins); axb.bar(bins[:-1] + 2.5 + off, c, width=1.7, color=col)
    axb.set_ylabel("Passengers"); axb.set_xlabel("Age (years)"); axb.set_xlim(0, 80); axb.grid(axis="y", color=GRID)
    titled(fig, "Survival was highest for the youngest children and, among males, fell steeply through childhood",
           f"Kernel-smoothed survival probability by age (bandwidth 5 years; band = 95% bootstrap interval). Males: {m_u5:.0%} under age 5 versus {m_13:.0%} at 13 and over.",
           f"Source: {len(real)} passengers with a recorded age (imputed ages are excluded here). Curves are drawn only where at least 12 effective observations support them.")
    save(fig, "fig04_age_curves")


# ---------------------------------------------------------------- Figure 5: correlation
def fig_correlation(E):
    corr = E["correlation_matrix"]
    labels = {"Survived": "Survived", "Female": "Female", "Pclass_n": "Class (1-3)", "Fare_Log": "log Fare", "Has_Cabin": "Cabin recorded", "Age": "Age", "Family_Size": "Family size",
              "SibSp": "SibSp", "Parch": "Parch", "Is_Alone": "Alone", "Ticket_Size": "Ticket size"}
    order = list(labels)
    c = corr.loc[order, order]
    mask = np.triu(np.ones_like(c, dtype=bool), k=1)
    fig, ax = plt.subplots(figsize=(10.5, 8.2)); fig.subplots_adjust(left=0.17, right=0.98, top=0.78, bottom=0.17)
    sns.heatmap(c, mask=mask, annot=True, fmt=".2f", cmap="RdBu_r", center=0, vmin=-1, vmax=1, square=True, linewidths=1.5, linecolor="white", cbar_kws={"shrink": 0.7, "label": "Spearman correlation"},
                annot_kws={"fontsize": 9.5}, ax=ax)
    ax.set_xticklabels([labels[o] for o in order], rotation=40, ha="right", fontsize=10.5); ax.set_yticklabels([labels[o] for o in order], rotation=0, fontsize=10.5)
    ax.add_patch(plt.Rectangle((0, 0), 1, len(order), fill=False, ec=INK, lw=2.2, clip_on=False))
    s = E["spearman_with_survival"]
    titled(fig, f"Being female (+{s['Female']:.2f}) and travelling in a lower class ({s['Pclass_n']:.2f}) correlate most with survival",
           f"Spearman rank correlations (lower triangle). Class and log fare move together (r = {E['spearman_pclass_fare']:.2f}), a collinearity warning for any model that uses both.",
           SRC + " Boxed column: correlation of each variable with survival.")
    save(fig, "fig05_correlation")


# ---------------------------------------------------------------- Figure 6: odds ratios
def fig_odds(I):
    coef = [c for c in I["coef"] if c["term"] != "Intercept" and c["term"] != "log(Age)"]
    ad = I["or_age_doubling"]
    coef.append({"term": "Age (each doubling)", "OR": ad["OR"], "OR_low": ad["low"], "OR_high": ad["high"], "p": next(c["p"] for c in I["coef"] if c["term"] == "log(Age)")})
    coef = [c for c in coef if "Family size, linear" not in c["term"]]
    fig, ax = plt.subplots(1, 2, figsize=(13.5, 6.8), gridspec_kw={"width_ratios": [1.7, 1]}); fig.subplots_adjust(left=0.2, right=0.97, top=0.71, bottom=0.14, wspace=0.62)
    a = ax[0]; ys = np.arange(len(coef))[::-1]
    for y, c in zip(ys, coef):
        col = SURV if c["p"] < 0.05 else "#9A9A9A"
        a.plot([c["OR_low"], c["OR_high"]], [y, y], color=col, lw=3, alpha=0.6, solid_capstyle="round"); a.plot(c["OR"], y, "o", color=col, ms=11, zorder=3)
        a.text(250, y, f"{c['OR']:.2f}  ({c['OR_low']:.2f} to {c['OR_high']:.2f})", va="center", fontsize=9.5, color=MUTED, ha="left")
    a.axvline(1, color="#888888", ls="--"); a.set_xscale("log"); a.set_xlim(0.01, 250); a.set_yticks(ys); a.set_yticklabels([c["term"] for c in coef], fontsize=10.5); a.grid(axis="x", color=GRID)
    a.set_xlabel("Adjusted odds ratio (log scale, 95% CI)"); a.set_title("All model terms (blue = p < 0.05)", loc="left", fontsize=12.5, color=MUTED)
    b = ax[1]; sx = I["sex_or_by_class"]; yy = np.arange(3)[::-1]
    for y, r in zip(yy, sx):
        b.plot([r["low"], r["high"]], [y, y], color=WOMEN, lw=3.5, alpha=0.6, solid_capstyle="round"); b.plot(r["OR"], y, "o", color=WOMEN, ms=12, zorder=3)
        b.text(r["OR"], y + 0.22, f"{r['OR']:.0f}" if r["OR"] >= 10 else f"{r['OR']:.1f}", ha="center", fontsize=12.5, fontweight="bold", color=WOMEN)
    b.axvline(1, color="#888888", ls="--"); b.set_xscale("log"); b.set_xlim(1, 400); b.set_yticks(yy); b.set_yticklabels([f"{r['class']} class" for r in sx], fontsize=11.5); b.grid(axis="x", color=GRID)
    b.set_ylim(-0.6, 2.7); b.set_xlabel("Odds ratio, women vs men (log scale)"); b.set_title("Women's advantage by class", loc="left", fontsize=12.5, color=MUTED)
    port = I["blocks"]["port"]; inter = I["blocks"]["interaction"]
    titled(fig, f"Sex, class and age drive survival; the women's advantage depends on class (interaction p < 0.001) and port has no significant independent effect (p = {port['p']:.2f})",
           f"Logistic regression with a sex-by-class interaction, n = {I['final_fit']['n']}; McFadden R-squared = {I['final_fit']['mcfadden']:.2f}. Likelihood-ratio test of the interaction: chi-square = {inter['chi2']:.1f} on {inter['df']} df.",
           SRC + " Odds ratios are conditional on the other variables in the model; first-class and second-class women intervals are wide because few of them died.")
    save(fig, "fig06_odds_ratios")


# ---------------------------------------------------------------- Figure 7: model comparison
def fig_models(I, M):
    cv = {r["model"]: r for r in I["cv"]}["M3 + sex x class"]
    nest = {r["model"]: r for r in M["nested"]}
    order = ["Logistic regression", "SVM (RBF)", "Random forest", "Gradient boosting"]
    fig, ax = plt.subplots(figsize=(11.5, 6.8)); fig.subplots_adjust(left=0.27, right=0.96, top=0.76, bottom=0.15)
    labels = ["Statistical logistic regression\n(sex x class model, all 891)"] + [f"{m} (tuned)" for m in order] + ["Chosen model on the\nheld-out test set"]
    ys = np.arange(len(labels))[::-1]
    pts = [(cv["AUC"], cv["AUC_sd"], "#009E73")] + [(nest[m]["nested_AUC"], nest[m]["nested_AUC_sd"], SURV) for m in order]
    for y, (mu, sd, col) in zip(ys[:-1], pts):
        ax.plot([mu - sd, mu + sd], [y, y], color=col, lw=3.5, alpha=0.5, solid_capstyle="round"); ax.plot(mu, y, "o", color=col, ms=13, zorder=4)
        ax.text(mu, y + 0.27, f"{mu:.3f}", ha="center", fontsize=12.5, fontweight="bold", color=col)
    tauc, tci = M["test_05"]["auc"], M["test_ci"]["auc"]
    ax.plot(tci, [ys[-1]] * 2, color=DIED, lw=3.5, alpha=0.5, solid_capstyle="round"); ax.plot(tauc, ys[-1], "D", color=DIED, ms=12, zorder=4); ax.text(tauc, ys[-1] + 0.27, f"{tauc:.3f}", ha="center", fontsize=12.5, fontweight="bold", color=DIED)
    ax.set_yticks(ys); ax.set_yticklabels(labels, fontsize=11.5); ax.set_xlim(0.74, 0.96); ax.set_ylim(-0.6, len(labels) - 0.4); ax.grid(axis="x", color=GRID)
    ax.set_xlabel("ROC AUC (1.0 = perfect ranking; 0.5 = coin flip, far to the left of this axis)")
    spread = max(p[0] for p in pts) - min(p[0] for p in pts)
    titled(fig, f"The classical model and four tuned machine-learning models perform alike (AUC {min(p[0] for p in pts):.2f} to {max(p[0] for p in pts):.2f}); the uncertainty exceeds the gaps",
           "Dot = mean AUC; bar = plus or minus one standard deviation across cross-validation folds (green, blue) or the 95% bootstrap interval on the test set (orange).",
           f"Source: 5x5 repeated CV of the statistical model on all passengers; nested CV of the ML models on the {M['split']['n_train']} training passengers; test set of {M['split']['n_test']} used once. Spread between models: {spread:.3f}.")
    save(fig, "fig07_model_comparison")


# ---------------------------------------------------------------- Figure 8: test performance
def fig_test(M, ctx):
    y_test, p_test, oof, y_train, thr = ctx["y_test"], ctx["p_test"], ctx["oof"], ctx["y_train"], ctx["thr"]
    t = M["test_thr"]
    fig, ax = plt.subplots(1, 3, figsize=(14, 5.6)); fig.subplots_adjust(left=0.06, right=0.985, top=0.74, bottom=0.14, wspace=0.28)
    fp, tp, _ = roc_curve(y_test, p_test); ax[0].plot(fp, tp, color=SURV, lw=3, label=f"Test set: AUC {M['test_05']['auc']:.3f}")
    fo, to, _ = roc_curve(y_train, oof); ax[0].plot(fo, to, color="#7F7F7F", lw=2, label=f"Training (out-of-fold): AUC {M['threshold']['oof_auc']:.3f}")
    ax[0].plot([0, 1], [0, 1], "--", color="#BBBBBB"); ax[0].set_xlabel("False positive rate"); ax[0].set_ylabel("True positive rate"); ax[0].legend(fontsize=9.5, loc="lower right", frameon=False); ax[0].set_title("Ranking quality (ROC)", loc="left", fontsize=12.5, color=INK, fontweight="bold")
    sns.heatmap([[t["tn"], t["fp"]], [t["fn"], t["tp"]]], annot=True, fmt="d", cmap=sns.light_palette(SURV, as_cmap=True), cbar=False, linewidths=3, linecolor="white", annot_kws={"fontsize": 22, "fontweight": "bold"},
                xticklabels=["Predicted died", "Predicted survived"], yticklabels=["Died", "Survived"], ax=ax[1]); ax[1].set_title(f"Test errors (cut-off {thr:.2f})", loc="left", fontsize=12.5, color=INK, fontweight="bold"); ax[1].tick_params(length=0)
    for pp, yt, col, lab, nb in [(oof, y_train, "#7F7F7F", "Training (out-of-fold)", 8), (p_test, y_test, SURV, "Test set", 5)]:
        fr, mp = calibration_curve(yt, pp, n_bins=nb, strategy="quantile"); ax[2].plot(mp, fr, "o-", color=col, lw=2.5, ms=8, label=lab)
    ax[2].plot([0, 1], [0, 1], "--", color="#BBBBBB"); ax[2].set_xlabel("Predicted survival probability"); ax[2].set_ylabel("Observed survival rate"); ax[2].legend(fontsize=9.5, frameon=False, loc="upper left"); ax[2].set_title("Calibration", loc="left", fontsize=12.5, color=INK, fontweight="bold")
    ci = M["test_ci"]["auc"]
    titled(fig, f"On unseen passengers the model reaches AUC {M['test_05']['auc']:.2f} and finds {t['recall']:.0%} of survivors, at {t['precision']:.0%} precision",
           f"{M['split']['n_test']} test passengers, used once. 95% bootstrap interval for AUC: {ci[0]:.2f} to {ci[1]:.2f}. The cut-off {thr:.2f} was chosen on training data only to maximise F1.",
           f"Source: random forest; majority-class baseline accuracy on the test set is {M['split']['baseline_acc_test']:.1%} versus {t['accuracy']:.1%} for the model at this cut-off.")
    save(fig, "fig08_test_performance")


# ---------------------------------------------------------------- Figure 9: importance and errors
def fig_importance_errors(M):
    imp = pd.DataFrame(M["perm_importance"]).sort_values("mean")
    eg = pd.DataFrame(M["error_groups"])
    fig, ax = plt.subplots(1, 2, figsize=(13.5, 6.6), gridspec_kw={"width_ratios": [1, 1.1]}); fig.subplots_adjust(left=0.09, right=0.97, top=0.76, bottom=0.14, wspace=0.42)
    a = ax[0]; cols = [SURV if m > 0.01 else "#9A9A9A" for m in imp["mean"]]
    a.barh(imp.feature, imp["mean"], xerr=imp["sd"], color=cols, error_kw=dict(ecolor="#555555", lw=1.2)); a.axvline(0, color="#888888", lw=1)
    a.set_xlabel("Drop in test AUC when the feature is shuffled"); a.set_title("What the model relies on", loc="left", fontsize=12.5, color=INK, fontweight="bold"); a.grid(axis="x", color=GRID)
    b = ax[1]; eg = eg.assign(label=eg.apply(lambda r: f"{'Women' if r.Sex == 'female' else 'Men'}, class {r.Pclass}", axis=1)).iloc[::-1]
    b.barh(eg.label, eg.accuracy, color=[WOMEN if "Women" in l else MEN for l in eg.label])
    for i, (_, r) in enumerate(eg.iterrows()):
        b.text(r.accuracy + 0.015, i, f"{r.accuracy:.0%}  (n={int(r.n)}; {r.survival_rate:.0%} survived)", va="center", fontsize=10.5, color=INK)
    b.set_xlim(0, 1.45); b.set_xticks([0, .25, .5, .75, 1.0]); b.xaxis.set_major_formatter(PercentFormatter(1)); b.set_xlabel("Test accuracy"); b.set_title("Where it errs", loc="left", fontsize=12.5, color=INK, fontweight="bold"); b.grid(axis="x", color=GRID)
    worst = eg.sort_values("accuracy").head(2)
    errs_in_worst = int(sum(round(r.n * (1 - r.accuracy)) for _, r in worst.iterrows()))
    titled(fig, f"The model relies on sex, title and class; {errs_in_worst} of its {M['error_summary']['n_errors']} test errors fall in just two groups",
           f"Permutation importance on the test set (left) and accuracy by sex and class (right, cut-off {M['threshold']['thr_f1']:.2f}). The hardest groups are those where the outcome was close to a coin flip.",
           "Source: random forest on the held-out test set. Correlated features share importance, so one-at-a-time shuffling understates each of them (title mostly carries age and sex).")
    save(fig, "fig09_importance_errors")


def make_all(df, prov, log, E, I, M, ctx):
    style()
    fig_workflow(prov, log, E, I, M)
    fig_data_quality(E, log)
    fig_sex_class(E)
    fig_age(df)
    fig_correlation(E)
    fig_odds(I)
    fig_models(I, M)
    fig_test(M, ctx)
    fig_importance_errors(M)
