"""Stage 4: statistical modelling and hypothesis testing (logistic regression with likelihood-ratio tests)."""
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import roc_auc_score, accuracy_score, brier_score_loss
from . import config


def prepare(df):
    """Model frame: dummy variables, log(age), centred family size and its square."""
    d = df.copy()
    d["Pclass"] = d.Pclass.astype(int)
    d["Female"] = (d.Sex == "Female").astype(int)
    d["P2"] = (d.Pclass == 2).astype(int)
    d["P3"] = (d.Pclass == 3).astype(int)
    d["Emb_C"] = (d.Embarked == "Cherbourg").astype(int)
    d["Emb_Q"] = (d.Embarked == "Queenstown").astype(int)
    d["FS_c"] = d.Family_Size - d.Family_Size.mean()
    d["FS_c2"] = d.FS_c ** 2
    d["LA"] = np.log(d.Age)
    d["Age_lnAge"] = d.Age * np.log(d.Age)
    d["Age_c"] = d.Age - 30
    d["Age_c2"] = d.Age_c ** 2
    d["Child"] = (d.Age < 13).astype(int)
    d["Age_u15"] = np.minimum(d.Age, 15)
    return d


def hosmer_lemeshow(y, p, g=10):
    d = pd.DataFrame({"y": np.asarray(y), "p": np.asarray(p)})
    d["grp"] = pd.qcut(d.p.rank(method="first"), g, labels=False)
    t = d.groupby("grp").agg(n=("y", "size"), obs=("y", "sum"), exp=("p", "sum"), pbar=("p", "mean"))
    chi2 = (((t.obs - t.exp) ** 2) / (t.exp * (1 - t.pbar))).sum()
    return float(chi2), g - 2, float(stats.chi2.sf(chi2, g - 2))


BASE = "Survived ~ Female + P2 + P3 + FS_c + FS_c2 + Emb_C + Emb_Q + Female:P2 + Female:P3"
MODELS = {
    "M0 null": "Survived ~ 1",
    "M1 sex + class": "Survived ~ Female + P2 + P3",
    "M2 + age, family, port": "Survived ~ Female + P2 + P3 + LA + FS_c + FS_c2 + Emb_C + Emb_Q",
    "M3 + sex x class": "Survived ~ Female + P2 + P3 + LA + FS_c + FS_c2 + Emb_C + Emb_Q + Female:P2 + Female:P3",
    "M4 + sex x age": "Survived ~ Female + P2 + P3 + LA + FS_c + FS_c2 + Emb_C + Emb_Q + Female:P2 + Female:P3 + Female:LA",
}
FINAL = "M3 + sex x class"


def assumptions(d):
    pred = ["Female", "P2", "P3", "LA", "FS_c", "FS_c2", "Emb_C", "Emb_Q"]
    X = sm.add_constant(d[pred])
    vif = {c: float(variance_inflation_factor(X.values, i)) for i, c in enumerate(X.columns) if c != "const"}
    bt = smf.logit("Survived ~ Female + P2 + P3 + Age + Age_lnAge + FS_c + FS_c2 + Emb_C + Emb_Q", data=d).fit(disp=0)
    events = int(d.Survived.sum())
    return {"events": events, "non_events": int(len(d) - events), "events_per_variable": round(min(events, len(d) - events) / len(pred), 1),
            "vif": vif, "vif_max": max(vif.values()), "boxtidwell_age_p": float(bt.pvalues["Age_lnAge"])}


def age_forms(d):
    forms = {"Linear in Age": " + Age", "Quadratic in Age": " + Age_c + Age_c2", "Child indicator (<13) + linear": " + Age + Child",
             "Piecewise linear (knot at 15)": " + Age + Age_u15", "Natural cubic spline (3 df)": " + cr(Age, df=3)", "log(Age)": " + LA"}
    rows = []
    for name, add in forms.items():
        m = smf.logit(BASE + add, data=d).fit(disp=0)
        rows.append({"form": name, "k": int(m.df_model) + 1, "logLik": float(m.llf), "AIC": float(m.aic), "BIC": float(m.bic),
                     "HL_p": hosmer_lemeshow(d.Survived, m.predict(d))[2]})
    m1 = smf.logit(BASE + " + LA", data=d).fit(disp=0)
    m2 = smf.logit(BASE + " + LA + I(LA**2)", data=d).fit(disp=0)
    return rows, float(stats.chi2.sf(2 * (m2.llf - m1.llf), 1))


def lincom(m, coefs):
    b, V = m.params, m.cov_params()
    c = pd.Series(0.0, index=b.index)
    for k, w in coefs.items():
        c[k] += w
    est = float(c @ b)
    se = float(np.sqrt(c @ V @ c))
    return {"OR": float(np.exp(est)), "low": float(np.exp(est - 1.96 * se)), "high": float(np.exp(est + 1.96 * se)), "p": float(2 * stats.norm.sf(abs(est / se)))}


def cross_validate_models(d, n_repeats=5):
    forms = {"Sex only": "Survived ~ Female", "M1 sex + class": MODELS["M1 sex + class"], "M2 + age, family, port": MODELS["M2 + age, family, port"],
             "M3 + sex x class": MODELS["M3 + sex x class"], "M4 + sex x age": MODELS["M4 + sex x age"]}
    rs = RepeatedStratifiedKFold(n_splits=5, n_repeats=n_repeats, random_state=7)
    out = []
    for name, f in forms.items():
        auc, acc, br = [], [], []
        for tr, te in rs.split(d, d.Survived):
            mm = smf.logit(f, data=d.iloc[tr]).fit(disp=0)
            p = mm.predict(d.iloc[te])
            auc.append(roc_auc_score(d.Survived.iloc[te], p)); acc.append(accuracy_score(d.Survived.iloc[te], p >= .5)); br.append(brier_score_loss(d.Survived.iloc[te], p))
        out.append({"model": name, "AUC": float(np.mean(auc)), "AUC_sd": float(np.std(auc)), "Accuracy": float(np.mean(acc)), "Brier": float(np.mean(br))})
    return out


def run(df, n_repeats=5):
    d = prepare(df)
    R = {"assumptions": assumptions(d)}
    R["age_forms"], R["age_resid_curvature_p"] = age_forms(d)
    fits = {k: smf.logit(f, data=d).fit(disp=0) for k, f in MODELS.items()}
    R["compare"] = [{"model": k, "k": int(m.df_model) + 1, "logLik": float(m.llf), "AIC": float(m.aic), "BIC": float(m.bic), "McFadden_R2": float(m.prsquared)} for k, m in fits.items()]

    def lr(a, b):
        st = 2 * (fits[b].llf - fits[a].llf)
        df_ = int(fits[b].df_model - fits[a].df_model)
        return {"from": a, "to": b, "chi2": float(st), "df": df_, "p": float(stats.chi2.sf(st, df_))}

    names = list(MODELS)
    R["lrt"] = [lr(names[i], names[i + 1]) for i in range(len(names) - 1)]

    def drop_block(terms):
        rhs = [t.strip() for t in MODELS[FINAL].split("~")[1].split("+")]
        m0 = smf.logit("Survived ~ " + " + ".join(t for t in rhs if t not in terms), data=d).fit(disp=0)
        st = 2 * (fits[FINAL].llf - m0.llf)
        return {"chi2": float(st), "df": len(terms), "p": float(stats.chi2.sf(st, len(terms)))}

    R["blocks"] = {"age": drop_block(["LA"]), "family_both": drop_block(["FS_c", "FS_c2"]), "family_quad": drop_block(["FS_c2"]),
                   "port": drop_block(["Emb_C", "Emb_Q"]), "interaction": drop_block(["Female:P2", "Female:P3"])}
    m = fits[FINAL]
    rob = smf.logit(MODELS[FINAL], data=d).fit(disp=0, cov_type="HC0")
    ci = m.conf_int()
    labels = {"Intercept": "Intercept", "Female": "Female (first class, vs male)", "P2": "Second class (men)", "P3": "Third class (men)", "LA": "log(Age)",
              "FS_c": "Family size, linear (centred)", "FS_c2": "Family size, squared", "Emb_C": "Cherbourg (vs Southampton)", "Emb_Q": "Queenstown (vs Southampton)",
              "Female:P2": "Female x second class", "Female:P3": "Female x third class"}
    R["coef"] = [{"term": labels[k], "OR": float(np.exp(m.params[k])), "OR_low": float(np.exp(ci.loc[k, 0])), "OR_high": float(np.exp(ci.loc[k, 1])),
                  "p": float(m.pvalues[k]), "p_robust": float(rob.pvalues[k])} for k in m.params.index]
    R["or_age_doubling"] = {"OR": float(np.exp(m.params["LA"] * np.log(2))), "low": float(np.exp(ci.loc["LA", 0] * np.log(2))), "high": float(np.exp(ci.loc["LA", 1] * np.log(2)))}
    n = m.nobs
    R["final_fit"] = {"n": int(n), "lr_chi2": float(m.llr), "lr_p": float(m.llr_pvalue), "mcfadden": float(m.prsquared), "aic": float(m.aic), "bic": float(m.bic),
                      "nagelkerke": float((1 - np.exp(2 * (m.llnull - m.llf) / n)) / (1 - np.exp(2 * m.llnull / n)))}
    R["sex_or_by_class"] = [{"class": c, **lincom(m, {"Female": 1, **({e: 1} if e else {})})} for c, e in [("First", None), ("Second", "Female:P2"), ("Third", "Female:P3")]]
    chi2, dof, p = hosmer_lemeshow(d.Survived, m.predict(d))
    R["hosmer_lemeshow"] = {"chi2": chi2, "df": dof, "p": p}
    m4 = fits["M4 + sex x age"]
    ln2 = np.log(2)

    def doubling(coefs):
        r = lincom(m4, coefs)
        return {"OR_doubling": float(np.exp(np.log(r["OR"]) * ln2)), "low": float(np.exp(np.log(r["low"]) * ln2)), "high": float(np.exp(np.log(r["high"]) * ln2)), "p": r["p"]}

    R["m4"] = {"men": doubling({"LA": 1}), "women": doubling({"LA": 1, "Female:LA": 1}), "interaction_p": float(m4.pvalues["Female:LA"]),
               "aic": float(m4.aic), "bic": float(m4.bic), "aic_m3": float(m.aic), "bic_m3": float(m.bic)}
    R["cv"] = cross_validate_models(d, n_repeats=n_repeats)
    # Reference predictions: passenger aged 28, travelling alone, boarded at Southampton
    fs_mean = df.Family_Size.mean()

    def pred(female, cls):
        row = pd.DataFrame({"Female": [female], "P2": [int(cls == 2)], "P3": [int(cls == 3)], "LA": [np.log(28)], "FS_c": [1 - fs_mean], "Emb_C": [0], "Emb_Q": [0]})
        row["FS_c2"] = row.FS_c ** 2
        return float(m.predict(row)[0])

    R["reference_predictions"] = {f"{s}_{c}": pred(f, c) for s, f in [("Female", 1), ("Male", 0)] for c in [1, 2, 3]}
    return R
