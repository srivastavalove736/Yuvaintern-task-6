"""Assemble, cross-check and compare the results of a pipeline run (shared by run_pipeline.py and the notebook)."""
import platform
import numpy as np
import pandas as pd
import scipy, sklearn, statsmodels, matplotlib
from . import integrate
from .utils import to_jsonable

# Reference values reported in the weekly deliverables (Weeks 1-4); the integrated pipeline must reproduce them.
REFERENCE = [
    ("Week 1", "Missing ages in the raw data", 177, lambda r: r["provenance"]["missing"]["Age"], 0),
    ("Week 1", "Missing cabins in the raw data", 687, lambda r: r["provenance"]["missing"]["Cabin"], 0),
    ("Week 1", "Columns in the cleaned dataset", 26, lambda r: r["cleaning"]["shape_clean"][1], 0),
    ("Week 2", "Chi-square, survival vs sex", 263.05, lambda r: next(t for t in r["eda"]["tests"] if t["test"] == "Survival vs Sex")["statistic"], 0.01),
    ("Week 2", "Cramer's V, survival vs sex", 0.543, lambda r: next(t for t in r["eda"]["tests"] if t["test"] == "Survival vs Sex")["effect"], 0.001),
    ("Week 3", "AIC of the sex-by-class model", 744.0, lambda r: next(m for m in r["inference"]["compare"] if m["model"].startswith("M3"))["AIC"], 0.1),
    ("Week 3", "Odds ratio, first-class women vs men", 50.6, lambda r: r["inference"]["sex_or_by_class"][0]["OR"], 0.1),
    ("Week 3", "LR chi-square, sex x class interaction", 33.55, lambda r: r["inference"]["blocks"]["interaction"]["chi2"], 0.01),
    ("Week 3", "Cross-validated AUC, sex-by-class model", 0.865, lambda r: next(m for m in r["inference"]["cv"] if m["model"].startswith("M3"))["AUC"], 0.001),
    ("Week 4", "Training / test split sizes", "712 / 179", lambda r: f"{r['ml']['split']['n_train']} / {r['ml']['split']['n_test']}", None),
    ("Week 4", "Selected model", "Random forest", lambda r: r["ml"]["selection"]["chosen"], None),
    ("Week 4", "Nested-CV AUC of the random forest", 0.882, lambda r: next(m for m in r["ml"]["nested"] if m["model"] == "Random forest")["nested_AUC"], 0.001),
    ("Week 4", "Decision threshold", 0.33, lambda r: r["ml"]["threshold"]["thr_f1"], 0.005),
    ("Week 4", "Test-set AUC", 0.850, lambda r: r["ml"]["test_05"]["auc"], 0.001),
]


def crosscheck(results, fast=False):
    rows = []
    for week, what, ref, getter, tol in REFERENCE:
        if fast and week == "Week 4":
            continue
        got = getter(results)
        ok = (got == ref) if tol is None else abs(float(got) - float(ref)) <= tol
        rows.append({"week": week, "quantity": what, "reference": ref, "reproduced": got if isinstance(got, str) else float(got), "match": bool(ok)})
    return rows


def environment():
    return {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__, "scipy": scipy.__version__,
            "scikit-learn": sklearn.__version__, "statsmodels": statsmodels.__version__, "matplotlib": matplotlib.__version__}


def assemble(prov, log, E, I, M, fast=False):
    """One JSON-serialisable dictionary holding every number used in the report."""
    eda_part = {k: v for k, v in E.items() if k != "correlation_matrix"}
    eda_part["correlation_matrix"] = E["correlation_matrix"].to_dict()
    results = to_jsonable({"provenance": prov, "cleaning": log, "eda": eda_part, "inference": I, "ml": M, "environment": environment(), "fast_mode": fast})
    results["crosscheck"] = crosscheck(results, fast)
    if not fast:
        results["integration"] = to_jsonable(integrate.triangulation(results["eda"], results["inference"], results["ml"]))
    return results


def _strip(o):
    if isinstance(o, dict):
        return {k: _strip(v) for k, v in o.items() if k != "runtime_seconds"}
    if isinstance(o, list):
        return [_strip(v) for v in o]
    return o


def identical(a, b):
    """True if two result dictionaries are exactly equal (ignoring wall-clock time)."""
    return _strip(a) == _strip(b)
