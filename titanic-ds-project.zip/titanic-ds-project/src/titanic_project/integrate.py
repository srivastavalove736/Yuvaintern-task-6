"""Stage 7: integration - triangulate each finding across EDA, statistical modelling and machine learning."""


def _imp(M, feat):
    return next((r["mean"] for r in M["perm_importance"] if r["feature"] == feat), float("nan"))


def _rate(E, key, level):
    return next(r for r in E["rates"][key] if r["level"] == level)


def triangulation(E, I, M):
    """Return one row per finding with the evidence from each of the three analytical approaches."""
    t = {x["test"]: x for x in E["tests"]}
    coef = {c["term"]: c for c in I["coef"]}
    sx = I["sex_or_by_class"]
    gap = {int(k): v for k, v in E["sex_class_gap_points"].items()}
    eg = {(r["Sex"], str(r["Pclass"])): r for r in M["error_groups"]}
    pc = {r["level"]: r for r in E["rates"]["Pclass"]}
    ad = I["or_age_doubling"]
    fam = {r["level"]: r for r in E["rates"]["Family_group"]}
    port = {r["level"]: r for r in E["rates"]["Embarked"]}
    rows = [
        {"finding": "Sex was the strongest factor",
         "eda": f"Women {_rate(E, 'Sex', 'Female')['rate']:.0%} vs men {_rate(E, 'Sex', 'Male')['rate']:.0%} survived; Cramer's V = {t['Survival vs Sex']['effect']:.2f}",
         "stats": f"Adjusted odds ratio for women: {sx[0]['OR']:.0f} (1st), {sx[1]['OR']:.0f} (2nd), {sx[2]['OR']:.1f} (3rd class)",
         "ml": f"Largest permutation importance: {_imp(M, 'Sex'):.3f} AUC drop",
         "verdict": "Consistent in all three approaches"},
        {"finding": "Class mattered, with a gradient",
         "eda": f"Survival {pc['1']['rate']:.0%} / {pc['2']['rate']:.0%} / {pc['3']['rate']:.0%} (1st/2nd/3rd); V = {t['Survival vs Pclass']['effect']:.2f}",
         "stats": f"Men: odds ratio {coef['Second class (men)']['OR']:.2f} (2nd) and {coef['Third class (men)']['OR']:.2f} (3rd) vs 1st class",
         "ml": f"Third-largest permutation importance: {_imp(M, 'Pclass'):.3f}",
         "verdict": "Consistent"},
        {"finding": "The women's advantage depends on class",
         "eda": f"Gap between women and men: {gap[1]:.0f}, {gap[2]:.0f} and {gap[3]:.0f} points in 1st, 2nd and 3rd class",
         "stats": f"Interaction likelihood-ratio test: chi-square = {I['blocks']['interaction']['chi2']:.1f}, p < 0.001",
         "ml": f"Learned without being specified: test accuracy {eg[('female', '1')]['accuracy']:.0%} / {eg[('female', '2')]['accuracy']:.0%} for 1st/2nd-class women but {eg[('female', '3')]['accuracy']:.0%} for 3rd class",
         "verdict": "Consistent; hardest group for the model"},
        {"finding": "Age mattered mainly for the very young, and non-linearly",
         "eda": f"Children under 5: {E['children_under5']['survived']} of {E['children_under5']['n']} survived ({E['children_under5']['survived'] / E['children_under5']['n']:.0%})",
         "stats": f"Odds ratio per doubling of age {ad['OR']:.2f} ({ad['low']:.2f} to {ad['high']:.2f}); straight-line form rejected (Box-Tidwell p = {I['assumptions']['boxtidwell_age_p']:.3f})",
         "ml": f"Age itself adds {_imp(M, 'Age'):.3f}: its information is carried by Title (importance {_imp(M, 'Title'):.3f})",
         "verdict": "Consistent once the overlap with title is understood"},
        {"finding": "Family size has an inverted-U effect",
         "eda": f"Survival {fam['Alone']['rate']:.0%} alone, {fam['2 to 4']['rate']:.0%} in families of 2 to 4, {fam['5 or more']['rate']:.0%} in families of 5 or more",
         "stats": f"Quadratic term significant (likelihood-ratio p = {I['blocks']['family_quad']['p']:.3f}); linear term alone is not",
         "ml": f"Small contribution: {_imp(M, 'Family_Size'):.3f}",
         "verdict": "Real but modest"},
        {"finding": "Port of embarkation is largely a composition effect",
         "eda": f"Cherbourg {port['Cherbourg']['rate']:.0%} vs Southampton {port['Southampton']['rate']:.0%}; V = {t['Survival vs Embarked']['effect']:.2f}",
         "stats": f"No significant independent effect after adjustment (joint likelihood-ratio p = {I['blocks']['port']['p']:.2f})",
         "ml": f"Negligible importance: {_imp(M, 'Embarked'):.3f}",
         "verdict": "EDA association disappears under adjustment"},
        {"finding": "Fare and cabin mostly reflect class",
         "eda": f"Class and log fare correlate at {E['spearman_pclass_fare']:.2f}; cabin recorded for {1 - E['missingness_raw']['First class']['Cabin']:.0%} of 1st vs {1 - E['missingness_raw']['Third class']['Cabin']:.0%} of 3rd class",
         "stats": "Class and fare cannot both be entered without collinearity; class carries the effect",
         "ml": f"Fare {_imp(M, 'Fare'):.3f}, cabin flag {_imp(M, 'Has_Cabin'):.3f}: little beyond class",
         "verdict": "Consistent: signposts, not separate causes"},
    ]
    return rows
