"""Central configuration: paths, random seeds and plotting palette."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW_PATH = ROOT / "data" / "raw" / "titanic.csv"
PROCESSED_DIR = ROOT / "data" / "processed"
CLEAN_PATH = PROCESSED_DIR / "titanic_cleaned.csv"
FIG_DIR = ROOT / "figures"
RESULTS_DIR = ROOT / "results"
MODELS_DIR = ROOT / "models"

SOURCE_URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
RANDOM_STATE = 42          # master seed (train/test split, models, searches)
TEST_SIZE = 0.20           # hold-out fraction for the machine-learning stage
ALPHA = 0.05               # significance level for hypothesis tests

# Colour language (Okabe-Ito, colour-blind safe): outcome colours are used consistently in every figure.
INK, MUTED, GRID = "#222222", "#6B6B6B", "#E6E6E6"
SURV, DIED = "#0072B2", "#D55E00"
WOMEN, MEN = "#CC79A7", "#009E73"
CLASS_COL = {1: "#7A5C00", 2: "#D1A400", 3: "#F2DC8A"}


def ensure_dirs():
    for p in (PROCESSED_DIR, FIG_DIR, RESULTS_DIR, MODELS_DIR):
        p.mkdir(parents=True, exist_ok=True)
