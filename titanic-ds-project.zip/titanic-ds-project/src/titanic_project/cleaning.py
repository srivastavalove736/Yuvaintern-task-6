"""Stage 2: cleaning and preprocessing (descriptive / inferential dataset).

Every decision is logged. The learned statistics (median ages, fare cap, scaling) use the full dataset, which is
appropriate for description and inference; the predictive stage (modeling.py) re-does imputation inside
cross-validation folds so that no information leaks from validation data.
"""
import numpy as np
import pandas as pd

CLEAN_COLUMNS_DOC = {
    "PassengerId": ("int", "original", "Unique row identifier"),
    "Survived": ("int8", "original", "Outcome: 1 = survived, 0 = died"),
    "Pclass": ("ordered category", "original", "Ticket class 1 < 2 < 3 (1 = first)"),
    "Name": ("text", "cleaned", "Passenger name; whitespace normalised"),
    "Sex": ("category", "cleaned", "Male / Female"),
    "Age": ("float", "imputed", "Age in years; missing values filled with median by Title x Pclass"),
    "SibSp": ("int", "original", "Siblings or spouses aboard"),
    "Parch": ("int", "original", "Parents or children aboard"),
    "Ticket": ("text", "original", "Ticket number"),
    "Fare": ("float", "original", "Ticket fare in pounds"),
    "Embarked": ("category", "cleaned", "Port: Southampton, Cherbourg, Queenstown (2 missing filled with mode)"),
    "Title": ("category", "derived", "Title extracted from Name and standardised (Mr, Mrs, Miss, Master, Officer, Noble, Professional)"),
    "Age_Imputed": ("int", "derived", "1 if Age was imputed"),
    "Has_Cabin": ("int", "derived", "1 if a cabin number was recorded"),
    "Deck": ("category", "derived", "First letter of the cabin, or Unknown"),
    "Fare_Zero": ("int", "derived", "1 if the recorded fare is zero"),
    "Ticket_Size": ("int", "derived", "Number of passengers sharing the ticket"),
    "Fare_Per_Person": ("float", "derived", "Fare divided by Ticket_Size"),
    "Fare_Capped": ("float", "derived", "Fare winsorised at its 99th percentile"),
    "Fare_Log": ("float", "derived", "log(1 + Fare)"),
    "Family_Size": ("int", "derived", "SibSp + Parch + 1"),
    "Is_Alone": ("int", "derived", "1 if Family_Size == 1"),
    "Age_Group": ("category", "derived", "Child (<12), Teen (12-17), YoungAdult (18-34), Adult (35-59), Senior (60+)"),
    "Age_MinMax": ("float", "derived", "Age scaled to [0, 1]"),
    "Fare_Log_Z": ("float", "derived", "Standardised log fare"),
    "Family_Size_Z": ("float", "derived", "Standardised family size"),
}


def clean(raw):
    """Return (cleaned dataframe, log of decisions and statistics)."""
    df = raw.copy()
    log = {"shape_raw": list(raw.shape)}

    def iqr_bounds(s):
        q1, q3 = s.quantile([.25, .75]); i = q3 - q1
        return q1 - 1.5 * i, q3 + 1.5 * i

    for c in ["Age", "Fare", "SibSp", "Parch"]:
        lo, hi = iqr_bounds(raw[c].dropna())
        log[f"iqr_{c}"] = {"low": round(float(lo), 2), "high": round(float(hi), 2),
                           "n_outliers": int(((raw[c] < lo) | (raw[c] > hi)).sum())}
    log["fare_skew_raw"] = round(float(raw.Fare.skew()), 2)
    log["fare_zero"] = int((raw.Fare == 0).sum())
    log["age_mean_raw"] = round(float(raw.Age.mean()), 2)

    # 1. text hygiene and titles
    df["Name"] = df["Name"].str.strip().str.replace(r"\s+", " ", regex=True)
    log["name_whitespace"] = int((raw.Name != raw.Name.str.strip()).sum())
    df["Title"] = df.Name.str.extract(r",\s*([^.]*)\.")[0].str.strip()
    log["n_titles_raw"] = int(df.Title.nunique())
    df["Title"] = df.Title.replace({"Mlle": "Miss", "Ms": "Miss", "Mme": "Mrs"})
    df["Title"] = df.Title.replace(["Col", "Major", "Capt"], "Officer").replace(
        ["Don", "Lady", "Sir", "the Countess", "Jonkheer", "Dona"], "Noble")
    df["Title"] = df.Title.replace({"Dr": "Professional", "Rev": "Professional"})
    log["n_titles_clean"] = int(df.Title.nunique())

    # 2. Embarked: mode imputation (2 missing)
    mode = raw.Embarked.mode()[0]
    log["embarked_imputed_with"] = mode
    log["embarked_mode_pct"] = round(float(raw.Embarked.value_counts(normalize=True)[mode]) * 100, 1)
    df["Embarked"] = df["Embarked"].fillna(mode)

    # 3. Age: median by Title x Pclass, with a traceability flag
    df["Age_Imputed"] = df.Age.isna().astype(int)
    grp = df.groupby(["Title", "Pclass"]).Age.transform("median")
    ttl = df.groupby("Title").Age.transform("median")
    df["Age"] = df.Age.fillna(grp).fillna(ttl).fillna(df.Age.median()).round(1)
    log["age_mean_clean"] = round(float(df.Age.mean()), 2)

    # 4. Cabin: too sparse to impute -> flag + deck
    df["Has_Cabin"] = df.Cabin.notna().astype(int)
    df["Deck"] = df.Cabin.str[0].fillna("Unknown")
    df = df.drop(columns="Cabin")

    # 5. Fare: zero fares kept and flagged; per-person fare; winsorising; log transform
    df["Fare_Zero"] = (df.Fare == 0).astype(int)
    df["Ticket_Size"] = df.groupby("Ticket").PassengerId.transform("count")
    df["Fare_Per_Person"] = (df.Fare / df.Ticket_Size).round(4)
    cap = df.Fare.quantile(.99)
    log["fare_cap_p99"] = round(float(cap), 2)
    log["fare_capped_n"] = int((df.Fare > cap).sum())
    df["Fare_Capped"] = df.Fare.clip(upper=cap).round(4)
    df["Fare_Log"] = np.log1p(df.Fare).round(4)
    log["fare_skew_log"] = round(float(df.Fare_Log.skew()), 2)

    # 6. Feature engineering
    df["Family_Size"] = df.SibSp + df.Parch + 1
    df["Is_Alone"] = (df.Family_Size == 1).astype(int)
    df["Age_Group"] = pd.cut(df.Age, [0, 12, 18, 35, 60, 120],
                             labels=["Child", "Teen", "YoungAdult", "Adult", "Senior"], right=False)

    # 7. Types and labels
    df["Sex"] = df.Sex.str.strip().str.lower().map({"male": "Male", "female": "Female"})
    df["Embarked"] = df.Embarked.map({"S": "Southampton", "C": "Cherbourg", "Q": "Queenstown"})
    df["Survived"] = df.Survived.astype("int8")
    df["Pclass"] = pd.Categorical(df.Pclass, categories=[1, 2, 3], ordered=True)
    for c in ["Sex", "Embarked", "Title", "Deck", "Age_Group"]:
        df[c] = df[c].astype("category")
    df["Ticket"] = df.Ticket.str.strip()

    # 8. Scaling (descriptive use only)
    df["Age_MinMax"] = ((df.Age - df.Age.min()) / (df.Age.max() - df.Age.min())).round(4)
    df["Fare_Log_Z"] = ((df.Fare_Log - df.Fare_Log.mean()) / df.Fare_Log.std()).round(4)
    df["Family_Size_Z"] = ((df.Family_Size - df.Family_Size.mean()) / df.Family_Size.std()).round(4)

    log["checks"] = validate(df)
    log["shape_clean"] = list(df.shape)
    return df, log


def validate(df):
    """Automated data-quality assertions on the cleaned dataset."""
    return {
        "no_missing_values": bool(df.isna().sum().sum() == 0),
        "no_duplicate_rows": bool(df.duplicated().sum() == 0),
        "unique_passenger_id": bool(df.PassengerId.is_unique),
        "survived_binary": bool(df.Survived.isin([0, 1]).all()),
        "pclass_1_to_3": bool(df.Pclass.isin([1, 2, 3]).all()),
        "age_in_0_to_100": bool(df.Age.between(0.1, 100).all()),
        "fare_non_negative": bool((df.Fare >= 0).all()),
        "family_size_consistent": bool((df.Family_Size == df.SibSp + df.Parch + 1).all()),
        "age_minmax_in_unit_interval": bool(df.Age_MinMax.between(0, 1).all()),
    }


def data_dictionary(df):
    """Data dictionary of the cleaned dataset (one row per column)."""
    rows = []
    for c in df.columns:
        t, origin, desc = CLEAN_COLUMNS_DOC[c]
        rows.append({"column": c, "type": t, "origin": origin, "description": desc,
                     "n_unique": int(df[c].nunique()), "missing": int(df[c].isna().sum())})
    return pd.DataFrame(rows)
