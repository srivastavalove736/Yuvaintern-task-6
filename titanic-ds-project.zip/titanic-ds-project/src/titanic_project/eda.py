"""Stage 3: exploratory data analysis (descriptive statistics, group rates, association tests, correlation)."""
import numpy as np
import pandas as pd
from scipy import stats
from . import config
from .utils import wilson


def descriptive(df):
    num = ["Age", "Fare", "Fare_Per_Person", "SibSp", "Parch", "Family_Size", "Ticket_Size"]
    d = df[num].agg(["count", "mean", "median", "std", "min", "max"]).T
    d["IQR"] = df[num].quantile(.75) - df[num].quantile(.25)
    d["skew"] = df[num].skew()
    d["kurtosis"] = df[num].kurt()
    return d.round(2).reset_index().rename(columns={"index": "variable"}).to_dict("records")


def survival_rates(df, col, order=None):
    """Survival rate with 95 % Wilson interval for every level of a grouping column."""
    g = df.groupby(col, observed=True).Survived.agg(["sum", "count"])
    if order is not None:
        g = g.reindex(order)
    out = []
    for lvl, r in g.iterrows():
        lo, hi = wilson(int(r["sum"]), int(r["count"]))
        out.append({"level": str(lvl), "survived": int(r["sum"]), "n": int(r["count"]), "rate": float(r["sum"] / r["count"]), "lo": lo, "hi": hi})
    return out


def association_tests(df):
    """Chi-square (+ Cramer's V) for categorical predictors, Mann-Whitney / Kruskal-Wallis for numeric ones; Bonferroni-adjusted."""
    tests = []

    def chi(name, a, b):
        ct = pd.crosstab(a, b)
        chi2, p, dof, _ = stats.chi2_contingency(ct, correction=False)
        v = np.sqrt(chi2 / (ct.values.sum() * (min(ct.shape) - 1)))
        tests.append({"test": name, "method": "Chi-square", "statistic": float(chi2), "dof": int(dof), "p": float(p), "effect": float(v), "effect_name": "Cramer's V"})

    chi("Survival vs Sex", df.Sex, df.Survived)
    chi("Survival vs Pclass", df.Pclass, df.Survived)
    chi("Survival vs Embarked", df.Embarked, df.Survived)
    chi("Survival vs Is_Alone", df.Is_Alone, df.Survived)
    chi("Survival vs Has_Cabin", df.Has_Cabin, df.Survived)

    def mwu(name, x, y):
        u, p = stats.mannwhitneyu(x, y, alternative="two-sided")
        rbc = 1 - 2 * u / (len(x) * len(y))
        tests.append({"test": name, "method": "Mann-Whitney U", "statistic": float(u), "dof": None, "p": float(p), "effect": float(-rbc), "effect_name": "rank-biserial"})

    mwu("Age, survivors vs non-survivors", df.Age[df.Survived == 1], df.Age[df.Survived == 0])
    mwu("log Fare, survivors vs non-survivors", df.Fare_Log[df.Survived == 1], df.Fare_Log[df.Survived == 0])
    H, p = stats.kruskal(*[g.Age.values for _, g in df.groupby("Pclass", observed=True)])
    tests.append({"test": "Age across Pclass", "method": "Kruskal-Wallis", "statistic": float(H), "dof": 2, "p": float(p),
                  "effect": float((H - 3 + 1) / (len(df) - 3)), "effect_name": "epsilon-squared"})
    m = len(tests)
    for t in tests:
        t["p_bonferroni"] = float(min(1.0, t["p"] * m))
        t["significant"] = bool(t["p_bonferroni"] < config.ALPHA)
    return tests


def correlations(df):
    t = df.copy()
    t["Pclass_n"] = t.Pclass.astype(int)
    t["Female"] = (t.Sex == "Female").astype(int)
    cols = ["Survived", "Age", "Fare_Log", "Pclass_n", "Family_Size", "SibSp", "Parch", "Has_Cabin", "Is_Alone", "Ticket_Size", "Female"]
    corr = t[cols].corr(method="spearman")
    return corr, corr["Survived"].drop("Survived").sort_values(key=abs, ascending=False).round(3).to_dict()


def missingness(raw):
    """Share of missing values by passenger group (from the RAW file)."""
    groups = {"All": raw, "First class": raw[raw.Pclass == 1], "Second class": raw[raw.Pclass == 2], "Third class": raw[raw.Pclass == 3],
              "Died": raw[raw.Survived == 0], "Survived": raw[raw.Survived == 1]}
    return {g: {c: float(d[c].isna().mean()) for c in ["Cabin", "Age", "Embarked"]} for g, d in groups.items()}


def run(df, raw):
    R = {"descriptive": descriptive(df)}
    R["categorical_pct"] = {c: {str(k): round(float(v) * 100, 1) for k, v in df[c].value_counts(normalize=True).items()}
                            for c in ["Survived", "Pclass", "Sex", "Embarked", "Age_Group", "Title", "Has_Cabin", "Is_Alone"]}
    df = df.copy()
    df["Family_group"] = pd.cut(df.Family_Size, [0, 1, 4, 20], labels=["Alone", "2 to 4", "5 or more"])
    R["rates"] = {
        "Sex": survival_rates(df, "Sex"),
        "Pclass": survival_rates(df, "Pclass"),
        "Embarked": survival_rates(df, "Embarked"),
        "Age_Group": survival_rates(df, "Age_Group", ["Child", "Teen", "YoungAdult", "Adult", "Senior"]),
        "Family_group": survival_rates(df, "Family_group", ["Alone", "2 to 4", "5 or more"]),
        "Has_Cabin": survival_rates(df, "Has_Cabin"),
        "Sex_x_Pclass": [{**r, "sex": s, "pclass": int(c)} for s in ["Female", "Male"] for c in [1, 2, 3]
                         for r in survival_rates(df[(df.Sex == s) & (df.Pclass == c)].assign(g="x"), "g")],
    }
    R["overall_survival"] = float(df.Survived.mean())
    R["tests"] = association_tests(df)
    corr, surv_corr = correlations(df)
    R["spearman_with_survival"] = surv_corr
    R["spearman_pclass_fare"] = float(corr.loc["Pclass_n", "Fare_Log"])
    R["missingness_raw"] = missingness(raw)
    # Effect size with bootstrap interval: survival-rate gap women - men
    rng = np.random.default_rng(config.RANDOM_STATE)
    f = df.Survived[df.Sex == "Female"].values
    m = df.Survived[df.Sex == "Male"].values
    gaps = [rng.choice(f, len(f)).mean() - rng.choice(m, len(m)).mean() for _ in range(5000)]
    R["sex_gap"] = {"gap": float(f.mean() - m.mean()), "ci": [float(np.percentile(gaps, 2.5)), float(np.percentile(gaps, 97.5))]}
    R["sex_class_gap_points"] = {int(c): float(100 * (df[(df.Sex == "Female") & (df.Pclass == c)].Survived.mean() - df[(df.Sex == "Male") & (df.Pclass == c)].Survived.mean())) for c in [1, 2, 3]}
    real = df[df.Age_Imputed == 0]
    u5 = real[real.Age < 5]
    R["children_under5"] = {"survived": int(u5.Survived.sum()), "n": int(len(u5))}
    R["correlation_matrix"] = corr.round(3)
    return R
