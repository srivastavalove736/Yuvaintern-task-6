"""Stage 1: data collection and provenance."""
import hashlib
import pandas as pd
from . import config

RAW_SCHEMA = {
    "PassengerId": "Unique row identifier",
    "Survived": "Outcome: 1 = survived, 0 = died",
    "Pclass": "Ticket class (1 = first, 2 = second, 3 = third)",
    "Name": "Passenger name including title",
    "Sex": "male / female",
    "Age": "Age in years (fractional for infants); missing for some passengers",
    "SibSp": "Number of siblings or spouses aboard",
    "Parch": "Number of parents or children aboard",
    "Ticket": "Ticket number (shared by passengers travelling together)",
    "Fare": "Fare in pounds sterling for the ticket",
    "Cabin": "Cabin number; missing for most passengers",
    "Embarked": "Port of embarkation: S = Southampton, C = Cherbourg, Q = Queenstown",
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def load_raw(path=None):
    """Load the raw manifest exactly as published (no modification)."""
    return pd.read_csv(path or config.RAW_PATH)


def provenance(raw, path=None):
    """Record where the data came from and what it looks like before any cleaning."""
    path = path or config.RAW_PATH
    return {
        "source_url": config.SOURCE_URL,
        "file": str(path.name),
        "sha256": sha256(path),
        "n_rows": int(raw.shape[0]),
        "n_cols": int(raw.shape[1]),
        "columns": list(raw.columns),
        "dtypes": {c: str(t) for c, t in raw.dtypes.items()},
        "missing": {c: int(v) for c, v in raw.isna().sum().items() if v > 0},
        "missing_pct": {c: round(float(v) * 100, 1) for c, v in raw.isna().mean().items() if v > 0},
        "duplicate_rows": int(raw.duplicated().sum()),
        "duplicate_ids": int(raw.PassengerId.duplicated().sum()),
        "survival_rate": float(raw.Survived.mean()),
    }
