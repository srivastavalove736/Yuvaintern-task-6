# Weekly deliverables (Weeks 1-5)

The six-week internship produced one deliverable per week. They are kept here unchanged, exactly as submitted.
The **integrated project** in the repository root (Week 6) re-implements all of them as one pipeline and reproduces their headline numbers (see `results/results.json`, section `crosscheck`).

| Week | Topic | Report | Code |
|---|---|---|---|
| 1 | Data gathering, cleaning and preprocessing | `Week1_Data_Cleaning_Report.*` | `clean_titanic.py` |
| 2 | Exploratory data analysis | `Week2_EDA_Report.*` | `Week2_EDA_Titanic.ipynb` |
| 3 | Statistical modelling and hypothesis testing | `Week3_Statistical_Modeling_Report.*` | `Week3_Statistical_Modeling_Titanic.ipynb` |
| 4 | Machine-learning model development and evaluation | `Week4_ML_Model_Report.*` | `Week4_ML_Model_Titanic.ipynb` |
| 5 | Data visualization and communication | `Week5_Visualization_Report.*` | `Week5_Data_Visualization_Titanic.ipynb`, `week5_figures/` |

The notebooks read `titanic.csv`, `titanic_cleaned.csv` and `w4_results.json` from this folder, so they run in place
(`jupyter nbconvert --to notebook --execute <notebook>`). `clean_titanic.py` expects `titanic.csv` in the working directory.
