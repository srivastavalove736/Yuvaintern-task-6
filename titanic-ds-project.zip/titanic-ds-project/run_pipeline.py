#!/usr/bin/env python
"""End-to-end pipeline: ingest -> clean -> EDA -> inference -> machine learning -> figures.

Usage:
    python run_pipeline.py                 # full run (about 5 minutes on one CPU)
    python run_pipeline.py --fast          # reduced search/CV settings for smoke tests
    python run_pipeline.py --figures-only  # rebuild figures from results/results.json and models/ml_context.joblib
"""
import argparse, json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
import joblib
import numpy as np
import pandas as pd
from titanic_project import config, data, cleaning, eda, inference, modeling, viz, results as res

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true")
    ap.add_argument("--figures-only", action="store_true")
    ap.add_argument("--out", default=None, help="results file name (default results/results.json)")
    a = ap.parse_args()
    config.ensure_dirs()
    out = Path(a.out) if a.out else config.RESULTS_DIR / "results.json"
    t0 = time.time()
    raw = data.load_raw()
    df, log = cleaning.clean(raw)
    if a.figures_only:
        results = json.load(open(out))
        ctx = joblib.load(config.MODELS_DIR / "ml_context.joblib")
        E_corr = pd.DataFrame(results["eda"]["correlation_matrix"])
        E = {**results["eda"], "correlation_matrix": E_corr}
        viz.make_all(df, results["provenance"], results["cleaning"], E, results["inference"], results["ml"], ctx)
        print(f"figures rebuilt in {time.time() - t0:.0f}s"); return

    print("[1/6] ingest"); prov = data.provenance(raw)
    print("[2/6] clean"); df.to_csv(config.CLEAN_PATH, index=False); cleaning.data_dictionary(df).to_csv(config.PROCESSED_DIR / "data_dictionary.csv", index=False)
    print("[3/6] explore"); E = eda.run(df, raw)
    print("[4/6] statistical modelling"); I = inference.run(df)
    print("[5/6] machine learning"); M, ctx = modeling.run(raw, fast=a.fast)
    ids = pd.concat([pd.DataFrame({"PassengerId": ctx["ids_train"], "split": "train"}), pd.DataFrame({"PassengerId": ctx["ids_test"], "split": "test"})]).sort_values("PassengerId")
    ids.to_csv(config.PROCESSED_DIR / "split_ids.csv", index=False)
    pd.DataFrame({"PassengerId": ctx["ids_test"], "survived": ctx["y_test"], "predicted_probability": ctx["p_test"].round(4), "predicted_survived": (ctx["p_test"] >= ctx["thr"]).astype(int)}).to_csv(config.RESULTS_DIR / "test_predictions.csv", index=False)
    joblib.dump(ctx["final_pipe"], config.MODELS_DIR / "final_model.joblib"); joblib.dump(ctx, config.MODELS_DIR / "ml_context.joblib")
    results = res.assemble(prov, log, E, I, M, fast=a.fast)
    json.dump(results, open(out, "w"), indent=1)
    print("[6/6] figures")
    if not a.fast:
        viz.make_all(df, prov, log, E, I, M, ctx)
    bad = [c for c in results["crosscheck"] if not c["match"]]
    print(f"done in {time.time() - t0:.0f}s | cross-check vs weekly deliverables: {len(results['crosscheck']) - len(bad)}/{len(results['crosscheck'])} match" + (f" | MISMATCH: {bad}" if bad else ""))


if __name__ == "__main__":
    main()
