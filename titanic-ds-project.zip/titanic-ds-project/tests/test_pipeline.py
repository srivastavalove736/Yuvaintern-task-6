"""Unit and integration tests for the Titanic data-science pipeline.

Run with:  pytest -q
The slow machine-learning smoke test uses the reduced `fast` settings (about 40 seconds on one CPU).
"""
import json
import numpy as np
import pandas as pd
import pytest
from titanic_project import config, data, cleaning, eda, inference, modeling
from titanic_project.utils import wilson


@pytest.fixture(scope="module")
def raw():
    return data.load_raw()


@pytest.fixture(scope="module")
def cleaned(raw):
    return cleaning.clean(raw)


# ------------------------------------------------------------------ data and cleaning
def test_raw_data_shape_and_missingness(raw):
    prov = data.provenance(raw)
    assert (prov["n_rows"], prov["n_cols"]) == (891, 12)
    assert prov["missing"] == {"Age": 177, "Cabin": 687, "Embarked": 2}
    assert prov["duplicate_rows"] == 0 and prov["duplicate_ids"] == 0
    assert len(prov["sha256"]) == 64


def test_cleaning_invariants(cleaned):
    df, log = cleaned
    assert all(log["checks"].values()), log["checks"]
    assert df.shape == (891, 26)
    assert df.isna().sum().sum() == 0
    assert df.Age_Imputed.sum() == 177                      # every imputed age is flagged
    assert (df.Family_Size == df.SibSp + df.Parch + 1).all()
    assert set(df.Title.unique()) <= {"Mr", "Mrs", "Miss", "Master", "Officer", "Noble", "Professional"}


def test_cleaning_does_not_use_the_outcome(raw):
    """Preprocessing must be independent of Survived: shuffling the labels changes nothing else."""
    shuffled = raw.copy()
    shuffled["Survived"] = np.random.default_rng(0).permutation(raw.Survived.values)
    a, _ = cleaning.clean(raw)
    b, _ = cleaning.clean(shuffled)
    pd.testing.assert_frame_equal(a.drop(columns="Survived"), b.drop(columns="Survived"))


def test_cleaning_is_deterministic(raw):
    a, _ = cleaning.clean(raw)
    b, _ = cleaning.clean(raw)
    pd.testing.assert_frame_equal(a, b)


def test_saved_dataset_matches_pipeline(cleaned):
    if not config.CLEAN_PATH.exists():
        pytest.skip("run_pipeline.py has not been executed yet")
    df, _ = cleaned
    df.to_csv("/tmp/_fresh_clean.csv", index=False)
    pd.testing.assert_frame_equal(pd.read_csv("/tmp/_fresh_clean.csv"), pd.read_csv(config.CLEAN_PATH))


def test_data_dictionary_covers_every_column(cleaned):
    df, _ = cleaned
    dd = cleaning.data_dictionary(df)
    assert list(dd.column) == list(df.columns)
    assert dd.description.str.len().min() > 0


# ------------------------------------------------------------------ EDA
def test_wilson_interval_contains_estimate():
    for k, n in [(3, 94), (72, 144), (0, 10), (10, 10)]:
        lo, hi = wilson(k, n)
        assert 0 <= lo <= k / n <= hi <= 1


def test_eda_results(cleaned, raw):
    df, _ = cleaned
    E = eda.run(df, raw)
    assert abs(E["overall_survival"] - 0.3838) < 1e-3
    sex = next(t for t in E["tests"] if t["test"] == "Survival vs Sex")
    assert sex["significant"] and 0.5 < sex["effect"] < 0.6
    assert all(t["p_bonferroni"] >= t["p"] for t in E["tests"])
    women = next(r for r in E["rates"]["Sex"] if r["level"] == "Female")
    assert women["lo"] < women["rate"] < women["hi"]
    assert E["correlation_matrix"].shape == (11, 11)


# ------------------------------------------------------------------ statistical inference
def test_inference_key_results(cleaned):
    df, _ = cleaned
    I = inference.run(df, n_repeats=1)
    assert I["assumptions"]["vif_max"] < 5                          # no problematic multicollinearity
    assert I["assumptions"]["boxtidwell_age_p"] < 0.05              # straight-line age effect is rejected ...
    best = min(I["age_forms"], key=lambda r: r["BIC"])
    assert best["form"] == "log(Age)"                               # ... and log(age) is the best form by BIC
    assert I["blocks"]["interaction"]["p"] < 0.001
    assert I["blocks"]["port"]["p"] > 0.05
    assert I["sex_or_by_class"][0]["OR"] > I["sex_or_by_class"][2]["OR"] > 1
    assert I["final_fit"]["mcfadden"] > 0.3


# ------------------------------------------------------------------ machine learning
def test_age_imputer_uses_training_data_only(raw):
    d = modeling.engineer(raw)
    train, test = d.iloc[:600], d.iloc[600:]
    imp = modeling.AgeImputer().fit(train)
    expected = train.groupby(["Title", "Pclass"]).Age.median().dropna().to_dict()
    assert imp.group_ == expected                                   # learned from training rows only
    changed = test.copy()
    changed["Age"] = changed.Age * 2                                # altering test ages must not alter what was learned
    assert modeling.AgeImputer().fit(train).group_ == imp.group_


def test_pipeline_predictions_do_not_depend_on_other_rows(raw):
    d = modeling.engineer(raw)
    X, y = d[modeling.FEATURES], d.Survived
    from sklearn.linear_model import LogisticRegression
    pipe = modeling.make_pipeline(LogisticRegression(max_iter=2000)).fit(X.iloc[:700], y.iloc[:700])
    batch = pipe.predict_proba(X.iloc[700:])[:, 1]
    single = np.array([pipe.predict_proba(X.iloc[[i]])[0, 1] for i in range(700, 710)])
    np.testing.assert_allclose(batch[:10], single, rtol=1e-9)       # no batch statistics leak into prediction


def test_ml_stage_smoke(raw):
    M, ctx = modeling.run(raw, fast=True, verbose=False)
    assert (M["split"]["n_train"], M["split"]["n_test"]) == (712, 179)
    assert abs(M["split"]["train_rate"] - M["split"]["test_rate"]) < 0.01      # stratified split
    assert M["test_05"]["auc"] > 0.80 and M["test_05"]["accuracy"] > M["split"]["baseline_acc_test"]
    assert set(ctx["ids_train"]).isdisjoint(set(ctx["ids_test"]))                # no passenger in both sets
    assert M["selection"]["chosen"] in M["selection"]["within_one_se"]


# ------------------------------------------------------------------ reproducibility of the full run
def test_full_run_matches_weekly_deliverables():
    path = config.RESULTS_DIR / "results.json"
    if not path.exists():
        pytest.skip("run_pipeline.py has not been executed yet")
    res = json.load(open(path))
    bad = [c for c in res["crosscheck"] if not c["match"]]
    assert not bad, bad
