"""Builds notebooks/00_integrated_project.ipynb (run:  python notebooks/build_master_notebook.py)."""
import nbformat as nbf
nb = nbf.v4.new_notebook(); cells = []
M = lambda s: cells.append(nbf.v4.new_markdown_cell(s.strip()))
C = lambda s: cells.append(nbf.v4.new_code_cell(s.strip()))

M("""
# Integrated Data Science Project: Who Survived the Titanic, and Can We Predict It?
**Master notebook (Week 6).** This notebook runs the *entire* pipeline, from the raw file to the final figures, by calling the functions in `src/titanic_project`. It produces exactly the numbers in the integrated report and finishes with a determinism check against `python run_pipeline.py`.

| Item | Description |
|---|---|
| **Real-world problem** | In a mass-casualty maritime evacuation, which passenger characteristics were associated with survival, and how well can survival be predicted from information known at boarding? The answers show how access to safety was unequal and how far a data-driven model can go. |
| **Data** | Public Titanic passenger manifest, 891 passengers, 12 columns (source URL and SHA-256 hash recorded). |
| **Techniques** | Data cleaning, exploratory analysis, hypothesis testing, logistic regression, machine learning with nested cross-validation, data visualization. |
| **Success criteria** | (1) cleaned dataset that passes automated checks; (2) statistically supported answers with effect sizes and uncertainty; (3) a predictive model evaluated on unseen data and compared with a classical benchmark; (4) every number reproducible by one command. |

**Stages:** 1 Ingest, 2 Clean, 3 Explore, 4 Statistical modelling, 5 Machine learning, 6 Visualization, 7 Integration.
""")

M("## 0. Setup")
C(r'''
import sys, json, time
from pathlib import Path
ROOT = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from IPython.display import Image, display
from titanic_project import config, data, cleaning, eda, inference, modeling, viz, integrate, results as res
pd.set_option("display.float_format", lambda v: f"{v:,.3f}"); pd.set_option("display.max_columns", 30); pd.set_option("display.width", 160)
config.ensure_dirs(); viz.style(); T0 = time.time()
def show(name, width=900): display(Image(filename=str(config.FIG_DIR / f"{name}.png"), width=width))
print("project root:", ROOT)
''')

M("## 1. Ingest: data collection and provenance\nThe raw file is loaded exactly as published. Its SHA-256 hash is recorded so that any later change to the input is detectable.")
C(r'''
raw = data.load_raw(); prov = data.provenance(raw)
print(f"{prov['n_rows']} rows x {prov['n_cols']} columns | SHA-256 {prov['sha256'][:16]}... | duplicates: {prov['duplicate_rows']} rows, {prov['duplicate_ids']} ids")
print("missing values:", prov["missing"], "| overall survival rate:", round(prov["survival_rate"], 4))
pd.DataFrame({"column": list(data.RAW_SCHEMA), "description": list(data.RAW_SCHEMA.values()), "dtype": [prov["dtypes"][c] for c in data.RAW_SCHEMA]})
''')

M("## 2. Clean: preprocessing with logged decisions\nThree columns need attention (age 19.9% missing, cabin 77.1% missing, port 2 values). Each decision is documented and checked by nine automated assertions. No rows are deleted.")
C(r'''
df, log = cleaning.clean(raw)
df.to_csv(config.CLEAN_PATH, index=False); dd = cleaning.data_dictionary(df); dd.to_csv(config.PROCESSED_DIR / "data_dictionary.csv", index=False)
decisions = pd.DataFrame([
    ["Age (177 missing)", "Median age by title x class; Age_Imputed flag keeps it traceable"],
    ["Cabin (687 missing)", "Not imputed (77% missing); replaced by Has_Cabin flag and Deck"],
    ["Embarked (2 missing)", f"Filled with the mode ({log['embarked_imputed_with']}, {log['embarked_mode_pct']}% of passengers)"],
    ["Fare (skew %.2f, %d zero fares)" % (log["fare_skew_raw"], log["fare_zero"]), f"Kept; zero fares flagged; capped at the 99th percentile ({log['fare_cap_p99']}); log transform (skew {log['fare_skew_log']})"],
    ["Names / titles", f"Whitespace stripped; {log['n_titles_raw']} raw titles standardised to {log['n_titles_clean']} groups"],
    ["Shared tickets", "Ticket_Size and Fare_Per_Person derived"]], columns=["Issue", "Decision"])
display(decisions); print("quality checks:", log["checks"]); print("cleaned shape:", df.shape)
dd.head(8)
''')

M("## 3. Explore: descriptive statistics, group rates and association tests")
C(r'''
E = eda.run(df, raw)
display(pd.DataFrame(E["descriptive"]))
rates = pd.DataFrame([{"group": g, **{k: r[k] for k in ("level", "survived", "n", "rate", "lo", "hi")}} for g in ("Sex", "Pclass", "Embarked", "Age_Group", "Family_group") for r in E["rates"][g]])
display(rates)
display(pd.DataFrame(E["tests"])[["test", "method", "statistic", "p_bonferroni", "effect", "effect_name", "significant"]])
print("sex gap (women - men): %.1f points, 95%% bootstrap CI %.1f to %.1f" % (100 * E["sex_gap"]["gap"], 100 * E["sex_gap"]["ci"][0], 100 * E["sex_gap"]["ci"][1]))
''')
C(r'''
viz.fig_data_quality(E, log); viz.fig_sex_class(E); viz.fig_age(df); viz.fig_correlation(E)
for n in ("fig02_data_quality", "fig03_sex_by_class", "fig04_age_curves", "fig05_correlation"): show(n)
''')
M("""
**Reading the EDA.** Survival was 38.4% overall but ranged from 14% (third-class men) to 97% (first-class women). Sex (Cramér's V 0.54) and class (V 0.34) show the strongest associations; the women's advantage was 60, 76 and 36 percentage points in first, second and third class. Age matters mostly for the very young, and the missing cabin numbers follow class and outcome, so the cabin record cannot be treated as random. Class and fare are strongly correlated (r = -0.69), a warning for modelling.
""")

M("## 4. Statistical modelling: logistic regression and hypothesis tests\nThe model is built stepwise and compared with likelihood-ratio tests and information criteria. Assumptions are checked first, and the one that fails (linearity in age) is fixed.")
C(r'''
I = inference.run(df)
A = I["assumptions"]
print(f"events per variable {A['events_per_variable']} | largest VIF {A['vif_max']:.2f} | Box-Tidwell p for a straight-line age effect {A['boxtidwell_age_p']:.4f} (violated)")
display(pd.DataFrame(I["age_forms"])); print("curvature left after log(Age): p = %.2f" % I["age_resid_curvature_p"])
display(pd.DataFrame(I["compare"])); display(pd.DataFrame(I["lrt"]))
print("block tests:", {k: (round(v["chi2"], 1), round(v["p"], 4)) for k, v in I["blocks"].items()})
''')
C(r'''
display(pd.DataFrame(I["coef"]).set_index("term"))
display(pd.DataFrame(I["sex_or_by_class"]))
f = I["final_fit"]; h = I["hosmer_lemeshow"]
print(f"final model: LR chi2 = {f['lr_chi2']:.1f}, McFadden R2 = {f['mcfadden']:.3f}, Nagelkerke R2 = {f['nagelkerke']:.3f}, AIC = {f['aic']:.1f}; Hosmer-Lemeshow p = {h['p']:.2f}")
print("age: odds ratio per doubling %.2f (%.2f to %.2f)" % tuple(I["or_age_doubling"][k] for k in ("OR", "low", "high")))
display(pd.DataFrame(I["cv"])); viz.fig_odds(I); show("fig06_odds_ratios", 1000)
''')
M("""
**Reading the model.** The women's odds of survival were about 51, 100 and 6 times the men's in first, second and third class (the interaction is highly significant, chi-square 33.6, p < 0.001). Each doubling of age multiplies the odds by 0.48. Family size has an inverted-U effect, while port of embarkation has no significant independent effect (p = 0.19). The model fits well (McFadden R-squared 0.39, Hosmer-Lemeshow p = 0.42) and its cross-validated AUC is 0.865.
""")

M("## 5. Machine learning: leakage-free pipelines, nested cross-validation and a single test-set evaluation\nAll fitted preprocessing lives inside the pipeline and is re-fitted on each training fold. A stratified 20% test set is held out and used once. The selection rule (highest nested AUC, prefer the simplest model within one standard error) is fixed before any result is seen. This cell takes about three minutes on one CPU.")
C(r'''
Mres, ctx = modeling.run(raw, fast=False, verbose=True)
print("split:", Mres["split"], "| model inputs:", Mres["n_model_inputs"])
display(pd.DataFrame(Mres["baseline"]).round(3))
''')
C(r'''
display(pd.DataFrame(Mres["nested"]).round(3))
print("selection:", Mres["selection"])
display(pd.DataFrame([{"model": t["model"], "best_cv_AUC": t["best_cv_AUC"], **t["params"]} for t in Mres["tuned"]]))
print("threshold:", {k: round(v, 3) for k, v in Mres["threshold"].items()})
''')
C(r'''
rows = {"Chosen model, cut-off 0.5": Mres["test_05"], f"Chosen model, cut-off {ctx['thr']:.2f}": Mres["test_thr"], **{f"{k} (0.5)": v for k, v in Mres["test_ref"].items()}}
display(pd.DataFrame(rows).T[["auc", "pr_auc", "accuracy", "precision", "recall", "f1", "mcc", "brier"]].round(3))
print("95%% bootstrap intervals (cut-off %.2f):" % ctx["thr"], {k: [round(x, 3) for x in v] for k, v in Mres["test_ci"].items()})
print("paired comparison with logistic regression:", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in Mres["paired"].items() if not isinstance(v, list)})
display(pd.DataFrame(Mres["error_groups"]).round(3)); print(Mres["error_summary"])
''')

M("## 6. Visualization of the modelling results")
C(r'''
viz.fig_models(I, Mres); viz.fig_test(Mres, ctx); viz.fig_importance_errors(Mres)
for n in ("fig07_model_comparison", "fig08_test_performance", "fig09_importance_errors"): show(n, 1000)
''')
M("""
**Reading the machine-learning results.** Four tuned models reach 0.87 to 0.89 AUC in nested cross-validation, within 0.02 of each other and of the classical logistic regression (0.865), while fold-to-fold variation is about 0.03: no model is demonstrably better. The rule selects the random forest, which scores AUC 0.850 (95% interval 0.78 to 0.91) and 80% accuracy on the 179 unseen passengers, against 61.5% for always predicting "died". Tuning mattered only for the random forest. The model relies on sex, title and class; its errors concentrate in first-class men and third-class women, where outcomes were close to a coin flip.
""")

M("## 7. Integration: do the three approaches agree?\nEach finding is checked against the evidence from exploratory analysis, statistical modelling and machine learning. The integrated pipeline must also reproduce every headline number reported in the weekly deliverables.")
C(r'''
results = res.assemble(prov, log, E, I, Mres, fast=False)
tri = pd.DataFrame(results["integration"]); pd.set_option("display.max_colwidth", 120); display(tri)
cc = pd.DataFrame(results["crosscheck"]); display(cc); print(f"cross-check against weekly deliverables: {int(cc.match.sum())}/{len(cc)} reproduced")
''')
C(r'''
viz.fig_workflow(prov, log, E, I, Mres); show("fig01_workflow", 1000)
''')

M("## 8. Save outputs and verify reproducibility\nThe notebook writes its own results file and compares it with the one produced by the command-line pipeline (`python run_pipeline.py`). The comparison ignores only wall-clock time.")
C(r'''
import joblib
json.dump(results, open(config.RESULTS_DIR / "results_notebook.json", "w"), indent=1)
cli_path = config.RESULTS_DIR / "results.json"
if cli_path.exists():
    cli = json.load(open(cli_path))
    same = res.identical(cli, results)
    print("notebook results identical to the command-line run:", same)
    assert same, "Notebook and CLI results differ"
else:
    print("results/results.json not found; run `python run_pipeline.py` to enable the comparison")
print(f"notebook finished in {time.time() - T0:.0f} s")
''')

M("""
## 9. Conclusions, limitations and next steps
- **What happened:** survival depended first on sex and class, in a way that varied by class (the women's advantage shrank from 76 points in second class to 36 in third); age mattered mostly for the youngest children; fare, cabin and port largely reflect class and who boarded where.
- **How well can we predict it:** AUC about 0.85 to 0.89 and about 80% accuracy; a simple logistic regression does as well as tuned ensembles.
- **Limitations:** observational historical data (associations, not causes); small groups (for example 94 first-class women); imputed ages; passengers are not independent (families); one 179-passenger test set gives wide intervals.
- **Next steps:** mixed-effects models for family groups, external validation on another dataset, probability calibration, and richer features such as cabin position.
- **Ethics:** the findings describe unequal access to safety in a historical disaster. They must not be used to rank people by sex or class in a real evacuation; the right lesson is to design procedures that do not depend on them.
""")
nb["cells"] = cells; nb.metadata = {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}}
nbf.write(nb, "notebooks/00_integrated_project.ipynb")
